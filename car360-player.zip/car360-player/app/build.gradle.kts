plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "bvack.car360"
    compileSdk = 34
    defaultConfig {
        applicationId = "bvack.car360"
        minSdk = 21
        // Low targetSdk keeps plain file-path access to USB drives working on head units.
        targetSdk = 28
        versionCode = 9
        versionName = "0.8"
    }
    signingConfigs {
        // A fixed debug key (same on every build) lets new versions install over old ones.
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.documentfile:documentfile:1.0.1")
    implementation("androidx.media3:media3-exoplayer:1.4.1")
    implementation("androidx.media3:media3-transformer:1.4.1")
    implementation("androidx.media3:media3-effect:1.4.1")
    implementation("androidx.media3:media3-ui:1.4.1")
}
