package bvack.car360

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.KeyEvent
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import org.xmlpull.v1.XmlPullParser
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Tools for finding out how the unit's mute button, radio and other parts behave, without adb or root:
 * system log (if the permission is granted), live audio state, mute tests, an app explorer that lists the
 * commands an app listens for, a command sender, and a screen inspector (needs accessibility).
 */
class DiagActivity : AppCompatActivity() {
    private lateinit var out: TextView
    private lateinit var outScroll: ScrollView
    private lateinit var fFilter: EditText
    private lateinit var fAction: EditText
    private lateinit var fPkg: EditText
    private lateinit var fCls: EditText
    private val handler = Handler(Looper.getMainLooper())
    private var capture: Process? = null
    private var watching = false
    private var lastAudio = ""
    private var evWatching = false

    private val save = registerForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) { contentResolver.openOutputStream(uri)?.use { it.write(out.text.toString().toByteArray()) }; toast("Saved") }
    }

    private fun audio() = getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 16, 16, 16) }
        val leftScroll = ScrollView(this).apply { addView(left) }
        out = TextView(this).apply { typeface = Typeface.MONOSPACE; textSize = 12f; setTextIsSelectable(true); setPadding(16, 16, 16, 16) }
        outScroll = ScrollView(this).apply { addView(out) }
        val root = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        root.addView(leftScroll, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        root.addView(outScroll, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1.3f))
        setContentView(root)

        fun head(s: String) = left.addView(TextView(this).apply { text = s; textSize = 17f; setTypeface(typeface, Typeface.BOLD); setPadding(0, 20, 0, 6) })
        fun row(vararg items: Pair<String, () -> Unit>) {
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for ((l, f) in items) r.addView(Button(this).apply { text = l; textSize = 12f; setOnClickListener { f() } }, LinearLayout.LayoutParams(0, -2, 1f))
            left.addView(r)
        }
        fun edit(hint: String, default: String = "") = EditText(this).apply { this.hint = hint; setText(default); setSingleLine() }.also { left.addView(it) }

        head("Output")
        row("Clear" to { out.text = "" }, "Save to file" to { save.launch("car360-diagnostics.txt") })

        head("System log (logcat)")
        fFilter = edit("filter words, separated by | (e.g. mute|radio|tuner)", "mute|radio|tuner|volume")
        row("Show recent" to { showLogcat() }, "Live capture on/off" to { toggleCapture() })
        row("Log permission?" to { logPermission() })

        head("Audio")
        row("Snapshot" to { log(audioInfo()) }, "Watch changes on/off" to { toggleWatch() })
        row("Mute: toggle" to { test("adjust TOGGLE_MUTE") { audio().adjustStreamVolume(3, AudioManager.ADJUST_TOGGLE_MUTE, 1) } },
            "Mute: mute" to { test("adjust MUTE") { audio().adjustStreamVolume(3, AudioManager.ADJUST_MUTE, 1) } })
        row("Mute: unmute" to { test("adjust UNMUTE") { audio().adjustStreamVolume(3, AudioManager.ADJUST_UNMUTE, 1) } },
            "Volume to 0" to { test("volume 0") { audio().setStreamVolume(3, 0, 1) } })
        row("Old setStreamMute on" to { test("setStreamMute(true)") { @Suppress("DEPRECATION") audio().setStreamMute(3, true) } },
            "Old setStreamMute off" to { test("setStreamMute(false)") { @Suppress("DEPRECATION") audio().setStreamMute(3, false) } })
        row("Key: VOLUME_MUTE" to { test("media key VOLUME_MUTE") { mediaKey(KeyEvent.KEYCODE_VOLUME_MUTE) } },
            "Broadcast MEDIA_BUTTON mute" to { test("MEDIA_BUTTON broadcast") { mediaButtonBroadcast(KeyEvent.KEYCODE_VOLUME_MUTE) } })
        row("Reset: unmute + 50%" to { test("reset") {
            audio().adjustStreamVolume(3, AudioManager.ADJUST_UNMUTE, 0)
            audio().setStreamVolume(3, audio().getStreamMaxVolume(3) / 2, 1)
        } })

        head("App explorer")
        val fApp = edit("part of an app name or package", "radio|tuner|fm|am")
        row("Search apps" to { listApps(fApp.text.toString()) })
        val fExplore = edit("exact package name to explore")
        row("Show what it listens for" to { explore(fExplore.text.toString().trim()) })

        head("Send a command to test")
        fAction = edit("action (for example a broadcast action)")
        fPkg = edit("package (optional)")
        fCls = edit("class (for starting an activity or service)")
        row("Send broadcast" to { sendBroadcastTest() }, "Start activity" to { startTest(false) }, "Start service" to { startTest(true) })

        head("Screen inspector (needs accessibility)")
        row("Dump screen in 5 s" to { dumpIn5() }, "Event watch on/off" to { toggleEvents() }, "Show events" to { log(A11yService.takeEvents().ifBlank { "(no events)" }) })
        row("Open accessibility settings" to { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })

        log("Pick a tool on the left. Results appear here.\nTip: use 'Watch changes' and press the unit's mute button or change the radio to see whether Android notices.")
    }

    private fun log(s: String) {
        val t = (out.text.toString() + "\n" + s).takeLast(60000)
        out.text = t.trimStart('\n')
        outScroll.post { outScroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    // ---------- logcat ----------

    private fun tokens() = fFilter.text.toString().split("|").map { it.trim().lowercase() }.filter { it.isNotEmpty() }
    private fun keep(line: String, t: List<String>) = t.isEmpty() || t.any { line.lowercase().contains(it) }

    private fun hasReadLogs() = ContextCompat.checkSelfPermission(this, "android.permission.READ_LOGS") == PackageManager.PERMISSION_GRANTED

    private fun logPermission() {
        log(if (hasReadLogs()) "READ_LOGS is granted: the system log shows other apps too."
        else "READ_LOGS is not granted, so logcat only shows this app's own lines.\n" +
            "It can only be granted from a computer (adb) or by an adb-style helper app such as Shizuku using the unit's own wireless debugging (Android 11 or newer).\n" +
            "Without it, use the Audio watch, App explorer and Screen inspector, which need no special permission.")
    }

    private fun showLogcat() {
        val t = tokens()
        Thread {
            val text = try {
                val p = Runtime.getRuntime().exec(arrayOf("logcat", "-d", "-v", "time", "-t", "3000"))
                p.inputStream.bufferedReader().readLines().filter { keep(it, t) }.takeLast(400).joinToString("\n")
            } catch (e: Exception) { "logcat failed: ${e.message}" }
            runOnUiThread { log(if (text.isBlank()) "(no matching lines; READ_LOGS granted: ${hasReadLogs()})" else text) }
        }.start()
    }

    private fun toggleCapture() {
        val running = capture
        if (running != null) { running.destroy(); capture = null; log("Capture stopped"); return }
        val t = tokens()
        val f = File(getExternalFilesDir(null) ?: filesDir, "logcat-" + SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date()) + ".txt")
        log("Capturing to ${f.absolutePath} (granted: ${hasReadLogs()})")
        Thread {
            try {
                val p = Runtime.getRuntime().exec(arrayOf("logcat", "-v", "time"))
                capture = p
                f.bufferedWriter().use { w ->
                    p.inputStream.bufferedReader().forEachLine { line ->
                        if (keep(line, t)) { w.write(line); w.newLine(); w.flush(); runOnUiThread { log(line) } }
                    }
                }
            } catch (e: Exception) { runOnUiThread { log("capture ended: ${e.message}") } }
        }.start()
    }

    // ---------- audio ----------

    private fun music(): String {
        val a = audio()
        val mute = if (Build.VERSION.SDK_INT >= 23) a.isStreamMute(3) else false
        return "vol=${a.getStreamVolume(3)}/${a.getStreamMaxVolume(3)} mute=$mute musicActive=${a.isMusicActive}"
    }

    private fun audioInfo(): String {
        val a = audio()
        val sb = StringBuilder("mode=${a.mode} ringer=${a.ringerMode} speakerphone=${a.isSpeakerphoneOn} micMute=${a.isMicrophoneMute}\n")
        val names = listOf(0 to "VOICE_CALL", 1 to "SYSTEM", 2 to "RING", 3 to "MUSIC", 4 to "ALARM", 5 to "NOTIFICATION", 10 to "ACCESSIBILITY")
        for ((s, n) in names) {
            val mute = if (Build.VERSION.SDK_INT >= 23) a.isStreamMute(s) else false
            sb.append("$n: ${a.getStreamVolume(s)}/${a.getStreamMaxVolume(s)} mute=$mute\n")
        }
        sb.append("musicActive=${a.isMusicActive}\n")
        if (Build.VERSION.SDK_INT >= 23) {
            sb.append("outputs: ").append(a.getDevices(AudioManager.GET_DEVICES_OUTPUTS).joinToString { "${typeName(it)}(${it.productName})" })
        }
        return sb.toString()
    }

    private fun typeName(d: AudioDeviceInfo): String = when (d.type) {
        AudioDeviceInfo.TYPE_BUILTIN_SPEAKER -> "speaker"
        AudioDeviceInfo.TYPE_BUS -> "bus"
        AudioDeviceInfo.TYPE_BLUETOOTH_A2DP -> "bt-a2dp"
        AudioDeviceInfo.TYPE_WIRED_HEADPHONES -> "wired"
        else -> "type${d.type}"
    }

    private val poll = object : Runnable {
        override fun run() {
            if (!watching) return
            val now = audioInfo()
            if (now != lastAudio) { log("[${SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())}] changed:\n$now"); lastAudio = now }
            handler.postDelayed(this, 700)
        }
    }

    private fun toggleWatch() {
        watching = !watching
        log(if (watching) "Watching audio state... press the mute button or change the source." else "Stopped watching")
        if (watching) { lastAudio = ""; handler.post(poll) }
    }

    private fun test(name: String, f: () -> Unit) {
        val before = music()
        try { f() } catch (e: Exception) { log("$name: error ${e.message}"); return }
        handler.postDelayed({ log("$name\n  before: $before\n  after:  ${music()}") }, 600)
    }

    private fun mediaKey(code: Int) {
        audio().dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        audio().dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun mediaButtonBroadcast(code: Int) {
        for (act in listOf(KeyEvent.ACTION_DOWN, KeyEvent.ACTION_UP))
            sendBroadcast(Intent(Intent.ACTION_MEDIA_BUTTON).putExtra(Intent.EXTRA_KEY_EVENT, KeyEvent(act, code)))
    }

    // ---------- app explorer ----------

    private fun listApps(q: String) {
        val t = q.split("|").map { it.trim().lowercase() }.filter { it.isNotEmpty() }
        Thread {
            val pm = packageManager
            val l = pm.getInstalledApplications(0).map { it.loadLabel(pm).toString() to it.packageName }
                .filter { (n, p) -> t.isEmpty() || t.any { n.lowercase().contains(it) || p.lowercase().contains(it) } }
                .sortedBy { it.first.lowercase() }
            runOnUiThread { log(if (l.isEmpty()) "(no apps match)" else l.joinToString("\n") { "${it.first}  --  ${it.second}" }) }
        }.start()
    }

    private fun explore(pkg: String) {
        if (pkg.isEmpty()) { toast("Type a package name first"); return }
        Thread {
            val text = try {
                val res = packageManager.getResourcesForApplication(packageManager.getApplicationInfo(pkg, 0))
                val p = res.assets.openXmlResourceParser("AndroidManifest.xml")
                val ns = "http://schemas.android.com/apk/res/android"
                val sb = StringBuilder("== $pkg ==\n")
                var ev = p.eventType
                while (ev != XmlPullParser.END_DOCUMENT) {
                    if (ev == XmlPullParser.START_TAG) {
                        when (p.name) {
                            "activity", "activity-alias", "service", "receiver", "provider" ->
                                sb.append("\n[${p.name}] ${p.getAttributeValue(ns, "name")}")
                                    .append(p.getAttributeValue(ns, "exported")?.let { "  exported=$it" } ?: "")
                            "action" -> sb.append("\n    action: ${p.getAttributeValue(ns, "name")}")
                            "uses-permission" -> sb.append("\npermission: ${p.getAttributeValue(ns, "name")}")
                        }
                    }
                    ev = p.next()
                }
                sb.toString()
            } catch (e: Exception) { "Could not read $pkg: ${e.message}" }
            runOnUiThread { log(text) }
        }.start()
    }

    // ---------- command sender ----------

    private fun sendBroadcastTest() {
        val a = fAction.text.toString().trim()
        if (a.isEmpty()) { toast("Type an action"); return }
        sendBroadcast(Intent(a).apply { fPkg.text.toString().trim().takeIf { it.isNotEmpty() }?.let { setPackage(it) } })
        log("Broadcast sent: $a ${fPkg.text}")
    }

    private fun startTest(service: Boolean) {
        val a = fAction.text.toString().trim(); val p = fPkg.text.toString().trim(); val c = fCls.text.toString().trim()
        try {
            val i = if (c.isNotEmpty() && p.isNotEmpty()) Intent().setClassName(p, c) else Intent(a)
            if (p.isNotEmpty() && c.isEmpty()) i.setPackage(p)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (service) startService(i) else startActivity(i)
            log("Started ${if (service) "service" else "activity"}: ${i.toUri(0)}")
        } catch (e: Exception) { log("Start failed: ${e.message}") }
    }

    // ---------- screen inspector ----------

    private fun dumpIn5() {
        if (A11yService.instance == null) { log("Accessibility is off. Turn on \"Car360\" in accessibility settings first."); return }
        toast("Switch to the app you want to inspect (5 s)")
        handler.postDelayed({ log(A11yService.instance?.dump() ?: "Accessibility is off") }, 5000)
    }

    private fun toggleEvents() {
        evWatching = !evWatching
        A11yService.watch = evWatching
        log(if (evWatching) "Event watch on: use the unit, then tap 'Show events'" else "Event watch off")
    }

    override fun onDestroy() {
        watching = false
        capture?.destroy()
        A11yService.watch = false
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
