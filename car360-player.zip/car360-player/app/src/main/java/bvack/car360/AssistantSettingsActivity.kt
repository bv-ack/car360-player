package bvack.car360

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.EditText
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat

class AssistantSettingsActivity : SettingsBase() {
    private val prefs by lazy { getSharedPreferences("assistant", Context.MODE_PRIVATE) }
    private var phrase: EditText? = null

    private val importMacros = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                Macros.save(this, contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() })
                toast("Macros loaded")
            } catch (e: Exception) { toast("Not a valid macros file") }
        }
    }

    private fun canOverlay() = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this)

    override fun build() {
        box.removeAllViews()
        text("Car360 Assistant", 24f)
        text("Set-up")
        button("1. Allow the microphone") { ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 1) }
        button("2. Allow display over other apps (floating button)") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        button("3. Turn on accessibility (optional: Back, Recents, tapping, screen inspector)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        text("Starting the assistant")
        toggle("Floating mic button", prefs, "overlay", false) { on ->
            if (on && !canOverlay()) toast("Allow display over other apps first")
            else if (on) startService(Intent(this, OverlayService::class.java)) else stopService(Intent(this, OverlayService::class.java))
        }
        text("Steering-wheel voice key: in the unit's own settings, assign the app \"Car360 Assistant\" (a second icon) to that key. " +
            "The assistant also answers the system voice-assistant request, if your unit sends one.", 14f)
        text("Speech")
        toggle("Prefer offline speech recognition", prefs, "offline", true)
        toggle("Speak replies", prefs, "speak", true)
        text("AI fallback (optional)")
        text("When no macro matches, the sentence can be sent to an AI service, which picks one of the allowed actions. " +
            "It needs internet and your own API key. Actions that act for you (navigation, web search, tapping) ask for an on-screen OK first.", 14f)
        toggle("Use AI when no macro matches", prefs, "ai", false)
        toggle("Ask before sending a sentence to the AI", prefs, "ai_confirm", true)
        field("API key", prefs, "ai_key", true)
        field("Model", prefs, "ai_model", false, "claude-haiku-5-5")
        text("Mute and other unit-specific commands")
        text("If the normal mute does not work on your unit, put the broadcast action you discover with Diagnostics here. " +
            "Mute will then send it instead.", 14f)
        field("Mute broadcast action", prefs, "mute_action")
        field("Mute broadcast package (optional)", prefs, "mute_pkg")
        text("Try a phrase")
        val et = EditText(this).apply { hint = "for example: set volume to fifty"; setSingleLine() }
        phrase = et
        box.addView(et)
        button("Run phrase") {
            val t = et.text.toString().trim()
            if (t.isNotEmpty()) startActivity(Intent(this, AssistantActivity::class.java).putExtra("text", t))
        }
        text("Macros")
        button("Load a macros file (.json)") { importMacros.launch(arrayOf("application/json", "text/*", "*/*")) }
        button("Back to the default macros") { Macros.reset(this); toast("Default macros restored") }
        button("Diagnostics (logs, audio, app explorer)") { startActivity(Intent(this, DiagActivity::class.java)) }
        text("Privacy: speech goes to the unit's recognition service, which may be online. The AI key is stored unencrypted in this app's private storage. " +
            "With the AI off, nothing is sent anywhere by the assistant.", 13f)
    }
}
