package bvack.car360

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Optional: asks an AI model to pick one allowed action. Only used when switched on and a key is set. */
object AiClient {
    fun ask(key: String, model: String, sentence: String): Pair<String, String> {
        val names = JSONArray(Actions.catalog.map { it.first })
        val help = Actions.catalog.joinToString("\n") { "${it.first}: ${it.second}" }
        val tool = JSONObject()
            .put("name", "run_action")
            .put("description", "Run exactly one allowed action on the car head unit.")
            .put("input_schema", JSONObject().put("type", "object")
                .put("properties", JSONObject()
                    .put("action", JSONObject().put("type", "string").put("enum", names))
                    .put("arg", JSONObject().put("type", "string").put("description", "Argument for the action, if it takes one.")))
                .put("required", JSONArray(listOf("action"))))
        val body = JSONObject()
            .put("model", model).put("max_tokens", 300)
            .put("system", "You control a car head unit by choosing one action from this list.\n$help\n" +
                "The user is driving, so keep spoken replies very short. If nothing fits, use the say action with a brief reply. Never invent actions.")
            .put("tools", JSONArray().put(tool))
            .put("tool_choice", JSONObject().put("type", "any"))
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", sentence)))
        val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.connectTimeout = 8000; c.readTimeout = 20000; c.doOutput = true
        c.setRequestProperty("content-type", "application/json")
        c.setRequestProperty("x-api-key", key)
        c.setRequestProperty("anthropic-version", "2023-06-01")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = c.responseCode
        val text = (if (code < 400) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
        if (code >= 400) throw IOException("HTTP $code ${text.take(160)}")
        val content = JSONObject(text).getJSONArray("content")
        for (i in 0 until content.length()) {
            val b = content.getJSONObject(i)
            if (b.optString("type") == "tool_use") {
                val inp = b.getJSONObject("input")
                return Pair(inp.optString("action", "say"), inp.optString("arg", ""))
            }
        }
        for (i in 0 until content.length()) {
            val b = content.getJSONObject(i)
            if (b.optString("type") == "text") return Pair("say", b.optString("text"))
        }
        throw IOException("empty AI answer")
    }
}
