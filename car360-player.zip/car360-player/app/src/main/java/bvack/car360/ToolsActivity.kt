package bvack.car360

import android.content.Intent

class ToolsActivity : SettingsBase() {
    override fun build() {
        text("Assistant, keyboard and tools", 24f)
        button("Assistant settings") { startActivity(Intent(this, AssistantSettingsActivity::class.java)) }
        button("Talk to the assistant now") { startActivity(Intent(this, AssistantActivity::class.java)) }
        button("Keyboard settings") { startActivity(Intent(this, KeyboardSettingsActivity::class.java)) }
        button("Diagnostics (logs, audio, app explorer)") { startActivity(Intent(this, DiagActivity::class.java)) }
    }
}
