package bvack.car360

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.Rect
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Optional. Lets the assistant press Back/Recents and on-screen text, and lets Diagnostics inspect the screen. */
class A11yService : AccessibilityService() {
    companion object {
        @Volatile var instance: A11yService? = null
        @Volatile var watch = false
        private val events = ArrayDeque<String>()
        fun takeEvents(): String = synchronized(events) { val s = events.joinToString("\n"); events.clear(); s }
    }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onInterrupt() {}

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (!watch || e == null) return
        val line = "${AccessibilityEvent.eventTypeToString(e.eventType)} ${e.packageName} ${e.className} text=${e.text} desc=${e.contentDescription}"
        synchronized(events) { events.addLast(line); while (events.size > 300) events.removeFirst() }
    }

    fun global(action: Int) = performGlobalAction(action)

    fun clickText(t: String): Boolean {
        val root = rootInActiveWindow ?: return false
        for (n in root.findAccessibilityNodeInfosByText(t)) {
            var c: AccessibilityNodeInfo? = n
            while (c != null && !c.isClickable) c = c.parent
            if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        }
        return false
    }

    fun dump(): String {
        val root = rootInActiveWindow ?: return "No active window"
        val sb = StringBuilder("package=${root.packageName}\n")
        fun walk(n: AccessibilityNodeInfo, d: Int) {
            val r = Rect(); n.getBoundsInScreen(r)
            sb.append("  ".repeat(d)).append(n.className).append(" text=").append(n.text).append(" desc=").append(n.contentDescription)
                .append(" id=").append(n.viewIdResourceName).append(if (n.isClickable) " [click]" else "").append(' ').append(r.toShortString()).append('\n')
            for (i in 0 until n.childCount) n.getChild(i)?.let { walk(it, d + 1) }
        }
        walk(root, 0)
        return sb.toString().take(30000)
    }
}
