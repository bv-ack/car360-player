package bvack.car360

import android.Manifest
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat

/** Setup and options for the Car360 keyboard. */
class KeyboardSettingsActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("kb", Context.MODE_PRIVATE) }
    private lateinit var box: LinearLayout

    private val importLayout = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                val text = contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }
                toast("Added layout: ${KbLayouts.saveUser(this, text).name}")
            } catch (e: Exception) { toast("Not a valid layout file") }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this)
        box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 24, 32, 24) }
        scroll.addView(box)
        setContentView(scroll)
        build()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun text(s: String, size: Float = 16f) = TextView(this).apply { text = s; textSize = size; setPadding(0, 16, 0, 8) }.also { box.addView(it) }

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label; setOnClickListener { action() }
    }.also { box.addView(it) }

    private fun stepper(label: String, value: () -> String, minus: () -> Unit, plus: () -> Unit) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 8, 0, 8) }
        row.addView(TextView(this).apply { text = label; textSize = 17f }, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(Button(this).apply { text = "-"; setOnClickListener { minus(); build() } })
        row.addView(TextView(this).apply { text = value(); textSize = 17f; minWidth = 160; gravity = android.view.Gravity.CENTER })
        row.addView(Button(this).apply { text = "+"; setOnClickListener { plus(); build() } })
        box.addView(row)
    }

    private fun build() {
        box.removeAllViews()
        text("Car360 Keyboard", 24f)
        text("Set-up (once)")
        button("1. Turn the keyboard on in system settings") { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        button("2. Switch to Car360 Keyboard") { (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker() }
        button("3. Allow the microphone (voice typing)") {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 1)
        }
        text("Options")
        stepper("Side", { prefs.getString("side", "left")!!.replaceFirstChar { it.uppercase() } },
            { flip("side", "left", "right") }, { flip("side", "left", "right") })
        stepper("Mode", { if (prefs.getString("mode", "over") == "over") "Over (app keeps size)" else "Docked (app shrinks)" },
            { flip("mode", "over", "docked") }, { flip("mode", "over", "docked") })
        stepper("Panel width", { "${prefs.getInt("widthPct", 50)}% of screen" },
            { step("widthPct", 50, -5, 30, 70) }, { step("widthPct", 50, 5, 30, 70) })
        stepper("Panel height", { "${prefs.getInt("heightPct", 75)}% of screen" },
            { step("heightPct", 75, -5, 30, 100) }, { step("heightPct", 75, 5, 30, 100) })
        stepper("Adaptive letters", { if (prefs.getBoolean("adaptive", false)) "On" else "Off" },
            { prefs.edit().putBoolean("adaptive", !prefs.getBoolean("adaptive", false)).apply() },
            { prefs.edit().putBoolean("adaptive", !prefs.getBoolean("adaptive", false)).apply() })
        stepper("Enter after voice", { if (prefs.getBoolean("voiceEnter", true)) "On" else "Off" },
            { prefs.edit().putBoolean("voiceEnter", !prefs.getBoolean("voiceEnter", true)).apply() },
            { prefs.edit().putBoolean("voiceEnter", !prefs.getBoolean("voiceEnter", true)).apply() })
        text("Layouts and learning")
        button("Add a layout file (.json)") { importLayout.launch(arrayOf("application/json", "text/*", "*/*")) }
        button("Forget learned letter usage") { Adaptive.reset(this); toast("Learned usage cleared") }
        text(
            "Adaptive letters move your most-used letters toward the top-middle of the panel and the least used toward " +
                "the bottom corners, a few letters at a time, and only after the keyboard has been hidden and shown again. Only a count per letter is " +
                "kept, on this device; the text you type is never stored or sent anywhere by this keyboard. " +
                "Voice typing uses the unit's own speech recognition service, which may send audio to its provider.", 14f
        )
    }

    private fun flip(key: String, a: String, b: String) {
        prefs.edit().putString(key, if (prefs.getString(key, a) == a) b else a).apply()
    }

    private fun step(key: String, def: Int, delta: Int, lo: Int, hi: Int) {
        prefs.edit().putInt(key, (prefs.getInt(key, def) + delta).coerceIn(lo, hi)).apply()
    }
}
