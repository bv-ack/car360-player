package bvack.car360

import android.content.SharedPreferences
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/** Small helpers for the plain settings screens. */
abstract class SettingsBase : AppCompatActivity() {
    protected lateinit var box: LinearLayout
    protected abstract fun build()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this)
        box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 24, 32, 24) }
        scroll.addView(box)
        setContentView(scroll)
        build()
    }

    protected fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    protected fun text(s: String, size: Float = 16f) =
        TextView(this).apply { text = s; textSize = size; setPadding(0, 16, 0, 8) }.also { box.addView(it) }

    protected fun button(label: String, action: () -> Unit) =
        Button(this).apply { text = label; setOnClickListener { action() } }.also { box.addView(it) }

    protected fun toggle(label: String, prefs: SharedPreferences, key: String, default: Boolean, onChange: (Boolean) -> Unit = {}) {
        val flip = { val v = !prefs.getBoolean(key, default); prefs.edit().putBoolean(key, v).apply(); onChange(v); build() }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 8, 0, 8) }
        row.addView(TextView(this).apply { text = label; textSize = 17f }, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(Button(this).apply { text = if (prefs.getBoolean(key, default)) "On" else "Off"; setOnClickListener { flip() } })
        box.addView(row)
    }

    protected fun field(label: String, prefs: SharedPreferences, key: String, password: Boolean = false, default: String = "") {
        text(label, 15f)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val et = EditText(this).apply {
            setText(prefs.getString(key, default)); setSingleLine()
            if (password) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        row.addView(et, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(Button(this).apply { text = "Save"; gravity = Gravity.CENTER; setOnClickListener {
            prefs.edit().putString(key, et.text.toString().trim()).apply(); toast("Saved")
        } })
        box.addView(row)
    }
}
