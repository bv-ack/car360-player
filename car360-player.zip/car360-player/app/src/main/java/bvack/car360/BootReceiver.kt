package bvack.car360

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings

/** Brings the floating mic button back after the unit starts, if it was switched on. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val on = ctx.getSharedPreferences("assistant", Context.MODE_PRIVATE).getBoolean("overlay", false)
        if (on && (Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(ctx))) {
            try { ctx.startService(Intent(ctx, OverlayService::class.java)) } catch (_: Exception) {}
        }
    }
}
