package bvack.car360

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.Locale

/** The voice assistant card. Start it from the floating button, the steering-wheel voice key, or Assistant settings. */
class AssistantActivity : Activity() {
    private lateinit var prefs: SharedPreferences
    private lateinit var head: TextView
    private lateinit var sub: TextView
    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var pendingSpeech: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("assistant", MODE_PRIVATE)
        buildUi()
        if (prefs.getBoolean("speak", true)) {
            tts = TextToSpeech(this) { st ->
                ttsReady = st == TextToSpeech.SUCCESS
                if (ttsReady) { tts?.language = Locale.US; pendingSpeech?.let { speak(it) } }
            }
        }
        val typed = intent.getStringExtra("text")
        if (typed != null) process(typed) else startListening()
    }

    private fun buildUi() {
        val d = resources.displayMetrics.density
        val root = FrameLayout(this).apply { setOnClickListener { finish() } }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val p = (20 * d).toInt(); setPadding(p, p, p, p)
            background = GradientDrawable().apply { setColor(0xF0202124.toInt()); cornerRadius = 18 * d }
            isClickable = true
        }
        head = TextView(this).apply { textSize = 24f; setTextColor(Color.WHITE); text = "Listening..." }
        sub = TextView(this).apply { textSize = 16f; setTextColor(0xFFB0B0B0.toInt()) }
        card.addView(head); card.addView(sub)
        card.addView(Button(this).apply { text = "Cancel"; setOnClickListener { finish() } })
        root.addView(card, FrameLayout.LayoutParams((resources.displayMetrics.widthPixels * 0.6f).toInt(),
            ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = (24 * d).toInt() })
        setContentView(root)
    }

    private fun startListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 7); return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            finishWith("No speech recognition on this unit. Try Assistant settings > Try a phrase."); return
        }
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { head.text = "Listening..." }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onError(error: Int) { finishWith("I didn't catch that (error $error)") }
            override fun onPartialResults(partialResults: Bundle?) {
                partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { head.text = it }
            }
            override fun onResults(results: Bundle?) {
                val said = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (said == null) finishWith("I didn't catch that") else process(said)
            }
        })
        r.startListening(
            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
                .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, prefs.getBoolean("offline", true))
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        )
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 7) {
            if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) startListening() else finishWith("Microphone not allowed")
        }
    }

    private fun process(said: String) {
        head.text = "\u201C$said\u201D"
        val m = Macros.match(this, said)
        if (m != null) { act(m.action, m.arg, m.confirm); return }
        if (prefs.getBoolean("ai", false) && prefs.getString("ai_key", "").orEmpty().isNotBlank()) askAi(said)
        else finishWith("I didn't understand")
    }

    private fun describe(action: String, arg: String) = "\"$action\"" + if (arg.isBlank()) "" else " ($arg)"

    private fun act(action: String, arg: String, confirm: Boolean) {
        if (confirm) confirmDialog("Run ${describe(action, arg)}?") { runNow(action, arg) } else runNow(action, arg)
    }

    private fun runNow(action: String, arg: String) { finishWith(Actions.run(this, action, arg)) }

    private fun confirmDialog(msg: String, yes: () -> Unit) {
        AlertDialog.Builder(this).setMessage(msg)
            .setPositiveButton("Allow") { _, _ -> yes() }
            .setNegativeButton("Cancel") { _, _ -> finish() }
            .setOnCancelListener { finish() }
            .show()
    }

    private fun askAi(said: String) {
        val model = prefs.getString("ai_model", "").orEmpty().ifBlank { "claude-haiku-5-5" }
        val key = prefs.getString("ai_key", "").orEmpty()
        val go = {
            head.text = "Asking AI..."
            Thread {
                try {
                    val (a, arg) = AiClient.ask(key, model, said)
                    runOnUiThread { aiResult(a, arg) }
                } catch (e: Exception) { runOnUiThread { finishWith("AI failed: ${e.message}") } }
            }.start()
        }
        if (prefs.getBoolean("ai_confirm", true)) confirmDialog("Send \"$said\" to the AI service ($model)?") { go() } else go()
    }

    private fun aiResult(action: String, arg: String) {
        if (action in Actions.aiNeedsOk) confirmDialog("The AI wants to run ${describe(action, arg)}. Allow?") { runNow(action, arg) }
        else runNow(action, arg)
    }

    private fun finishWith(msg: String) {
        head.text = msg
        speak(msg)
        handler.postDelayed({ if (!isFinishing) finish() }, 2500)
    }

    private fun speak(msg: String) {
        if (!prefs.getBoolean("speak", true)) return
        if (ttsReady) tts?.speak(msg, TextToSpeech.QUEUE_FLUSH, null, "a") else pendingSpeech = msg
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try { recognizer?.destroy() } catch (_: Exception) {}
        tts?.shutdown()
        super.onDestroy()
    }
}
