package bvack.car360

import android.content.Context
import android.graphics.SurfaceTexture
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.view.Surface
import org.json.JSONArray
import org.json.JSONObject
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/** One camera: pose from the head unit's calibinfo.lua plus generic fisheye values you can tune. */
class CamP(
    var pos: FloatArray, var look: FloatArray, var up: FloatArray,
    var cx: Float, var cy: Float,      // principal point, tile pixels (tile = 960x1080)
    var tx: Float, var ty: Float,      // tile origin as a fraction of the whole frame
    var f: Float = 300f,               // fisheye focal length in pixels (equidistant model)
    var k: Float = 0f,                 // extra distortion term
    var yaw: Float = 0f, var pitch: Float = 0f, var roll: Float = 0f,  // degrees
    var dy: Float = 0f,                // height tweak, mm
    var mirror: Boolean = false
) {
    fun copy() = CamP(pos.copyOf(), look.copyOf(), up.copyOf(), cx, cy, tx, ty, f, k, yaw, pitch, roll, dy, mirror)

    private fun sub(a: FloatArray, b: FloatArray) = floatArrayOf(a[0] - b[0], a[1] - b[1], a[2] - b[2])
    private fun dot(a: FloatArray, b: FloatArray) = a[0] * b[0] + a[1] * b[1] + a[2] * b[2]
    private fun cross(a: FloatArray, b: FloatArray) =
        floatArrayOf(a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])
    private fun norm(a: FloatArray): FloatArray { val l = sqrt(dot(a, a)); return floatArrayOf(a[0] / l, a[1] / l, a[2] / l) }
    private fun rot(v: FloatArray, axis: FloatArray, deg: Float): FloatArray {
        val a = Math.toRadians(deg.toDouble()); val c = cos(a).toFloat(); val s = sin(a).toFloat()
        val kv = cross(axis, v); val kd = dot(axis, v)
        return FloatArray(3) { v[it] * c + kv[it] * s + axis[it] * kd * (1 - c) }
    }

    /** Column-major 3x3 whose rows are camera right, down, forward (for GLSL). */
    fun basis(): FloatArray {
        var fw = norm(sub(look, pos))
        var right = norm(cross(fw, up))
        val u = cross(right, fw)
        var down = floatArrayOf(-u[0], -u[1], -u[2])
        fw = rot(fw, down, yaw); right = rot(right, down, yaw)
        fw = rot(fw, right, pitch); down = rot(down, right, pitch)
        right = rot(right, fw, roll); down = rot(down, fw, roll)
        return floatArrayOf(right[0], down[0], fw[0], right[1], down[1], fw[1], right[2], down[2], fw[2])
    }
}

class BevSettings {
    var cams: List<CamP> = defaultCams()
    var halfH = 5000f      // half the visible height, mm
    var cx = 380f          // view centre on the ground, mm
    var cz = -60f
    var carL = 4682f
    var carW = 1823f

    fun copy() = BevSettings().also { s ->
        s.cams = cams.map { it.copy() }; s.halfH = halfH; s.cx = cx; s.cz = cz; s.carL = carL; s.carW = carW
    }

    fun reset(cam: Int) {
        val d = defaultCams()
        if (cam in 0..3) { val o = cams[cam]; val n = d[cam]; n.cx = o.cx; n.cy = o.cy; n.pos = o.pos; n.look = o.look; n.up = o.up
            cams = cams.mapIndexed { i, c -> if (i == cam) n else c } }
        else { cams = d; halfH = 5000f; cx = 380f; cz = -60f }
    }

    fun adjust(cam: Int, param: String, dir: Int) {
        when (param) {
            "Zoom" -> halfH = (halfH * Math.pow(1.1, -dir.toDouble()).toFloat()).coerceIn(1500f, 20000f)
            "Center X" -> cx += 100f * dir
            "Center Z" -> cz += 100f * dir
            else -> {
                val targets = if (cam in 0..3) listOf(cams[cam]) else cams
                for (c in targets) when (param) {
                    "Focal" -> c.f = (c.f + 5f * dir).coerceIn(100f, 1000f)
                    "Distort" -> c.k += 0.01f * dir
                    "Yaw" -> c.yaw += 0.5f * dir
                    "Pitch" -> c.pitch += 0.5f * dir
                    "Roll" -> c.roll += 0.5f * dir
                    "Height" -> c.dy += 20f * dir
                }
                if (param == "Mirror") { val v = !targets[0].mirror; targets.forEach { it.mirror = v } }
            }
        }
    }

    fun value(cam: Int, param: String): String {
        val c = cams[if (cam in 0..3) cam else 0]
        return when (param) {
            "Zoom" -> "%.1f m visible".format(halfH * 2 / 1000)
            "Center X" -> "%.0f mm".format(cx)
            "Center Z" -> "%.0f mm".format(cz)
            "Focal" -> "%.0f px".format(c.f)
            "Distort" -> "%.2f".format(c.k)
            "Yaw" -> "%.1f deg".format(c.yaw)
            "Pitch" -> "%.1f deg".format(c.pitch)
            "Roll" -> "%.1f deg".format(c.roll)
            "Height" -> "%+.0f mm".format(c.dy)
            "Mirror" -> if (c.mirror) "on" else "off"
            else -> ""
        }
    }

    fun toJson(): String {
        val arr = JSONArray()
        for (c in cams) arr.put(JSONObject().apply {
            put("pos", JSONArray(c.pos.map { it.toDouble() })); put("look", JSONArray(c.look.map { it.toDouble() }))
            put("up", JSONArray(c.up.map { it.toDouble() }))
            put("cx", c.cx.toDouble()); put("cy", c.cy.toDouble()); put("tx", c.tx.toDouble()); put("ty", c.ty.toDouble())
            put("f", c.f.toDouble()); put("k", c.k.toDouble()); put("yaw", c.yaw.toDouble()); put("pitch", c.pitch.toDouble())
            put("roll", c.roll.toDouble()); put("dy", c.dy.toDouble()); put("mirror", c.mirror)
        })
        return JSONObject().apply {
            put("version", 2); put("note", "car360-player bird's-eye settings; mm, degrees, tile = 960x1080")
            put("view", JSONObject().put("halfH", halfH.toDouble()).put("cx", cx.toDouble()).put("cz", cz.toDouble())
                .put("carL", carL.toDouble()).put("carW", carW.toDouble()))
            put("cameras", arr)
        }.toString(2)
    }

    private fun fl(a: JSONArray) = FloatArray(a.length()) { a.getDouble(it).toFloat() }

    fun fromJson(t: String) {
        val o = JSONObject(t)
        val v = o.getJSONObject("view")
        halfH = v.getDouble("halfH").toFloat(); cx = v.getDouble("cx").toFloat(); cz = v.getDouble("cz").toFloat()
        carL = v.optDouble("carL", carL.toDouble()).toFloat(); carW = v.optDouble("carW", carW.toDouble()).toFloat()
        val a = o.getJSONArray("cameras")
        require(a.length() == 4)
        cams = (0 until 4).map { i ->
            val c = a.getJSONObject(i)
            CamP(fl(c.getJSONArray("pos")), fl(c.getJSONArray("look")), fl(c.getJSONArray("up")),
                c.getDouble("cx").toFloat(), c.getDouble("cy").toFloat(), c.getDouble("tx").toFloat(), c.getDouble("ty").toFloat(),
                c.getDouble("f").toFloat(), c.getDouble("k").toFloat(), c.getDouble("yaw").toFloat(),
                c.getDouble("pitch").toFloat(), c.getDouble("roll").toFloat(), c.getDouble("dy").toFloat(), c.getBoolean("mirror"))
        }
    }

    private val num = "(-?[0-9.]+(?:[eE][-+]?[0-9]+)?)"
    private fun lua(t: String, key: String, n: Int): List<List<Float>> {
        val re = Regex("\\b$key\\s*=\\s*\\{" + (1..n).joinToString(",") { "\\s*$num\\s*" })
        return re.findAll(t).map { m -> (1..n).map { m.groupValues[it].toFloat() } }.toList()
    }

    /** Accepts our JSON, the head unit's calibinfo.lua (camera poses), or setting.lua (car size). */
    fun importText(t: String): String {
        if (t.contains("CalibInfos")) {
            val pos = lua(t, "CameraPos", 3); val up = lua(t, "CameraUp", 3)
            val look = lua(t, "LookatPos", 3); val ctr = lua(t, "Center", 2)
            if (listOf(pos, up, look, ctr).any { it.size != 4 }) return "calibinfo.lua: expected 4 cameras, could not read it"
            cams = cams.mapIndexed { i, c ->
                c.copy().also {
                    it.pos = pos[i].toFloatArray(); it.up = up[i].toFloatArray(); it.look = look[i].toFloatArray()
                    it.cx = ctr[i][0]; it.cy = ctr[i][1]
                }
            }
            return "Imported camera poses from calibinfo.lua (lens values are kept as you tuned them)"
        }
        if (t.contains("VehicleInfo.CarLength")) {
            Regex("VehicleInfo\\.CarLength\\s*=\\s*$num").find(t)?.let { carL = it.groupValues[1].toFloat() }
            Regex("VehicleInfo\\.CarWidth\\s*=\\s*$num").find(t)?.let { carW = it.groupValues[1].toFloat() }
            return "Car size set to ${carL.toInt()} x ${carW.toInt()} mm"
        }
        return try { fromJson(t); "Settings loaded" } catch (e: Exception) { "Not a recognised calibration file" }
    }

    companion object {
        private fun f(vararg v: Float) = v
        fun defaultCams(): List<CamP> = listOf(
            CamP(f(2829.648f, 445.847f, -79.222f), f(4097.791f, 0f, 100.770f), f(0.32819f, 0.94424f, 0.02662f), 479.82f, 510.96f, 0f, 0f),
            CamP(f(536.316f, 1099.173f, 881.563f), f(862.858f, 0f, 1649.504f), f(0.22945f, 0.60233f, 0.76456f), 442.20f, 608.79f, 0f, 0.5f),
            CamP(f(-2084.311f, 994.795f, -274.287f), f(-3065.396f, 0f, -297.383f), f(-0.71208f, 0.70176f, 0.02170f), 494.27f, 561.13f, 0.5f, 0f),
            CamP(f(238.241f, 1277.584f, -773.683f), f(-163.994f, 0f, -1770.356f), f(-0.04434f, 0.62313f, -0.78086f), 424.31f, 608.37f, 0.5f, 0.5f)
        )
    }
}

/** Draws the ground plane from above by projecting every ground pixel into the four camera tiles. */
class BirdseyeView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) :
    GLSurfaceView(ctx, attrs), GLSurfaceView.Renderer, SurfaceTexture.OnFrameAvailableListener {

    var onSurface: ((Surface) -> Unit)? = null
    @Volatile private var s = BevSettings()
    private var prog = 0
    private var tex = 0
    private var st: SurfaceTexture? = null
    private val texMat = FloatArray(16)
    private var aspect = 1f
    private val quad = ByteBuffer.allocateDirect(32).order(ByteOrder.nativeOrder()).asFloatBuffer()
        .apply { put(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f)); position(0) }

    init {
        setEGLContextClientVersion(2)
        setRenderer(this)
        renderMode = RENDERMODE_WHEN_DIRTY
    }

    fun update(settings: BevSettings) { s = settings; requestRender() }
    override fun onFrameAvailable(t: SurfaceTexture?) = requestRender()

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        prog = link(VERT, FRAG)
        val t = IntArray(1)
        GLES20.glGenTextures(1, t, 0); tex = t[0]
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, tex)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        val tx = SurfaceTexture(tex)
        tx.setOnFrameAvailableListener(this)
        st = tx
        val surface = Surface(tx)
        Handler(Looper.getMainLooper()).post { onSurface?.invoke(surface) }
    }

    override fun onSurfaceChanged(gl: GL10?, w: Int, h: Int) {
        GLES20.glViewport(0, 0, w, h); aspect = w.toFloat() / h
    }

    override fun onDrawFrame(gl: GL10?) {
        GLES20.glClearColor(0f, 0f, 0f, 1f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        try { st?.updateTexImage(); st?.getTransformMatrix(texMat) } catch (_: Exception) { return }
        val set = s
        GLES20.glUseProgram(prog)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, tex)
        fun loc(n: String) = GLES20.glGetUniformLocation(prog, n)
        GLES20.glUniform1i(loc("uTex"), 0)
        GLES20.glUniformMatrix4fv(loc("uTexMat"), 1, false, texMat, 0)
        GLES20.glUniform2f(loc("uCenter"), set.cx / 1000f, set.cz / 1000f)
        GLES20.glUniform1f(loc("uHalfH"), set.halfH / 1000f)
        GLES20.glUniform1f(loc("uAspect"), aspect)
        GLES20.glUniform2f(loc("uCar"), set.carL / 1000f, set.carW / 1000f)
        for (i in 0..3) {
            val c = set.cams[i]
            GLES20.glUniform3f(loc("uPos$i"), c.pos[0] / 1000f, (c.pos[1] + c.dy) / 1000f, c.pos[2] / 1000f)
            GLES20.glUniformMatrix3fv(loc("uRot$i"), 1, false, c.basis(), 0)
            GLES20.glUniform4f(loc("uIn$i"), c.cx, c.cy, c.f, c.k)
            GLES20.glUniform3f(loc("uTile$i"), c.tx, c.ty, if (c.mirror) -1f else 1f)
        }
        val a = GLES20.glGetAttribLocation(prog, "aPos")
        GLES20.glEnableVertexAttribArray(a)
        GLES20.glVertexAttribPointer(a, 2, GLES20.GL_FLOAT, false, 0, quad)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(a)
    }

    private fun compile(type: Int, src: String): Int {
        val sh = GLES20.glCreateShader(type)
        GLES20.glShaderSource(sh, src); GLES20.glCompileShader(sh)
        return sh
    }

    private fun link(v: String, f: String): Int {
        val p = GLES20.glCreateProgram()
        GLES20.glAttachShader(p, compile(GLES20.GL_VERTEX_SHADER, v))
        GLES20.glAttachShader(p, compile(GLES20.GL_FRAGMENT_SHADER, f))
        GLES20.glLinkProgram(p)
        return p
    }

    companion object {
        const val VERT = "attribute vec2 aPos; varying vec2 vP; void main(){ vP = aPos; gl_Position = vec4(aPos, 0.0, 1.0); }"
        const val FRAG = """
#extension GL_OES_EGL_image_external : require
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
varying vec2 vP;
uniform samplerExternalOES uTex;
uniform mat4 uTexMat;
uniform vec2 uCenter; uniform float uHalfH; uniform float uAspect; uniform vec2 uCar;
uniform vec3 uPos0; uniform mat3 uRot0; uniform vec4 uIn0; uniform vec3 uTile0;
uniform vec3 uPos1; uniform mat3 uRot1; uniform vec4 uIn1; uniform vec3 uTile1;
uniform vec3 uPos2; uniform mat3 uRot2; uniform vec4 uIn2; uniform vec3 uTile2;
uniform vec3 uPos3; uniform mat3 uRot3; uniform vec4 uIn3; uniform vec3 uTile3;

vec4 camSample(vec3 pos, mat3 rot, vec4 intr, vec3 tile, vec3 P) {
  vec3 d = rot * (P - pos);
  float th = acos(clamp(d.z / length(d), -1.0, 1.0));
  if (th > 1.55) return vec4(0.0);
  float r = intr.z * (th + intr.w * th * th * th);
  vec2 dir = d.xy;
  float dl = length(dir);
  dir = dl > 0.000001 ? dir / dl : vec2(0.0);
  vec2 p = intr.xy + dir * r;
  if (tile.z < 0.0) p.x = 960.0 - p.x;
  float m = min(min(p.x, 960.0 - p.x), min(p.y, 1080.0 - p.y));
  if (m < 0.0) return vec4(0.0);
  vec2 uv = vec2(tile.x + p.x / 960.0 * 0.5, 1.0 - (tile.y + p.y / 1080.0 * 0.5));
  vec2 tc = (uTexMat * vec4(uv, 0.0, 1.0)).xy;
  float w = smoothstep(0.0, 30.0, m) * (1.0 - smoothstep(1.2, 1.55, th));
  return vec4(texture2D(uTex, tc).rgb, w);
}

float dw(vec3 pos, vec3 P) { return 1.0 / pow(1.0 + length(P.xz - pos.xz) / 1.5, 4.0); }

void main() {
  vec3 P = vec3(uCenter.x + vP.y * uHalfH, 0.0, uCenter.y + vP.x * uHalfH * uAspect);
  vec4 a = camSample(uPos0, uRot0, uIn0, uTile0, P);
  vec4 b = camSample(uPos1, uRot1, uIn1, uTile1, P);
  vec4 c = camSample(uPos2, uRot2, uIn2, uTile2, P);
  vec4 e = camSample(uPos3, uRot3, uIn3, uTile3, P);
  float wa = a.w * dw(uPos0, P); float wb = b.w * dw(uPos1, P);
  float wc = c.w * dw(uPos2, P); float we = e.w * dw(uPos3, P);
  float ws = wa + wb + wc + we;
  vec3 rgb = ws > 0.0005 ? (a.rgb * wa + b.rgb * wb + c.rgb * wc + e.rgb * we) / ws : vec3(0.1);
  vec2 q = abs(P.xz - uCenter);
  if (q.x < uCar.x * 0.5 && q.y < uCar.y * 0.5) rgb = mix(rgb, vec3(0.08), 0.85);
  gl_FragColor = vec4(rgb, 1.0);
}
"""
    }
}
