package bvack.car360

import android.content.Context
import org.json.JSONObject
import java.io.File

class Match(val action: String, val arg: String, val confirm: Boolean)

/** Voice phrases -> actions, read from macros.json (see MACROS.md). */
object Macros {
    private fun userFile(ctx: Context) = File(ctx.filesDir, "macros.json")
    private val slotRe = Regex("\\{(\\w+)\\}")

    fun json(ctx: Context): String =
        if (userFile(ctx).exists()) userFile(ctx).readText() else ctx.assets.open("macros.json").bufferedReader().use { it.readText() }

    fun save(ctx: Context, text: String) {
        val a = JSONObject(text).getJSONArray("macros")
        for (i in 0 until a.length()) { val m = a.getJSONObject(i); m.getJSONArray("say"); m.getString("action") }
        userFile(ctx).writeText(text)
    }

    fun reset(ctx: Context) { userFile(ctx).delete() }

    fun norm(s: String) = s.lowercase().replace(Regex("[^a-z0-9 ]"), " ").replace(Regex("\\s+"), " ").trim()

    private fun compile(p: String): Pair<Regex, List<String>> {
        val names = ArrayList<String>()
        val sb = StringBuilder("^")
        var last = 0
        for (m in slotRe.findAll(p)) {
            sb.append(Regex.escape(frag(p.substring(last, m.range.first))))
            sb.append("(.+)")
            names += m.groupValues[1]
            last = m.range.last + 1
        }
        sb.append(Regex.escape(frag(p.substring(last)))).append("$")
        return Pair(Regex(sb.toString()), names)
    }

    private fun frag(s: String) = s.lowercase().replace(Regex("[^a-z0-9 ]"), " ").replace(Regex(" +"), " ")

    fun match(ctx: Context, said: String): Match? {
        val t = norm(said).removePrefix("please ").trim()
        val arr = JSONObject(json(ctx)).getJSONArray("macros")
        for (i in 0 until arr.length()) {
            val m = arr.getJSONObject(i)
            val say = m.getJSONArray("say")
            for (j in 0 until say.length()) {
                val (re, names) = compile(norm0(say.getString(j)))
                val r = re.find(t) ?: continue
                var arg = m.optString("arg", "")
                names.forEachIndexed { k, n -> arg = arg.replace("{$n}", r.groupValues[k + 1].trim()) }
                return Match(m.getString("action"), arg, m.optBoolean("confirm", false))
            }
        }
        return null
    }

    // keep {slots} intact while lower-casing the phrase
    private fun norm0(s: String) = s.lowercase()
}
