package bvack.car360

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.view.KeyEvent
import android.accessibilityservice.AccessibilityService
import kotlin.math.roundToInt

object Actions {
    /** Actions the assistant (and the AI) can use, and what the argument means. */
    val catalog = listOf(
        "volume_up" to "Raise the volume one step.",
        "volume_down" to "Lower the volume one step.",
        "volume_set" to "Set the volume; arg is a percentage 0-100.",
        "mute_toggle" to "Mute or unmute the sound.",
        "open_app" to "Open an installed app; arg is the app name.",
        "navigate" to "Start navigation; arg is the place or address.",
        "search_web" to "Search the web in the browser; arg is the query.",
        "media_play" to "Resume media.", "media_pause" to "Pause media.",
        "media_next" to "Next track.", "media_previous" to "Previous track.",
        "home" to "Go to the home screen.",
        "back" to "Press Back (needs accessibility).",
        "recents" to "Open recent apps (needs accessibility).",
        "click_text" to "Tap the on-screen item with this text (needs accessibility); arg is the text.",
        "say" to "Only speak a short reply; arg is the reply."
    )

    /** When the AI picks one of these, an on-screen OK is asked first. */
    val aiNeedsOk = setOf("navigate", "search_web", "click_text")

    private val ones = listOf("zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven",
        "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen")
    private val tens = mapOf("twenty" to 20, "thirty" to 30, "forty" to 40, "fifty" to 50, "sixty" to 60, "seventy" to 70, "eighty" to 80, "ninety" to 90)

    fun parseNumber(s: String): Int? {
        s.trim().removeSuffix("%").trim().toIntOrNull()?.let { return it }
        var total = 0; var any = false
        for (w in Macros.norm(s).split(" ")) {
            val o = ones.indexOf(w)
            when {
                o >= 0 -> { total += o; any = true }
                tens.containsKey(w) -> { total += tens[w]!!; any = true }
                w == "hundred" -> { total = if (total == 0) 100 else total * 100; any = true }
                w == "percent" || w == "and" || w.isEmpty() -> {}
                else -> return null
            }
        }
        return if (any) total else null
    }

    private fun key(audio: AudioManager, code: Int) {
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    fun run(ctx: Context, action: String, arg: String): String {
        val audio = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val prefs = ctx.getSharedPreferences("assistant", Context.MODE_PRIVATE)
        return try {
            when (action) {
                "volume_up" -> { audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI); "Volume up" }
                "volume_down" -> { audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI); "Volume down" }
                "volume_set" -> {
                    val n = parseNumber(arg)
                    if (n == null) "I didn't catch the volume"
                    else {
                        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                        audio.setStreamVolume(AudioManager.STREAM_MUSIC, (n.coerceIn(0, 100) * max / 100f).roundToInt(), AudioManager.FLAG_SHOW_UI)
                        "Volume $n percent"
                    }
                }
                "mute_toggle" -> {
                    val act = prefs.getString("mute_action", "").orEmpty()
                    if (act.isNotBlank()) {
                        ctx.sendBroadcast(Intent(act).apply { prefs.getString("mute_pkg", "").orEmpty().takeIf { it.isNotBlank() }?.let { setPackage(it) } })
                        "Mute command sent"
                    } else { audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_TOGGLE_MUTE, AudioManager.FLAG_SHOW_UI); "Mute toggled" }
                }
                "open_app" -> openApp(ctx, arg)
                "navigate" -> navigate(ctx, arg)
                "search_web" -> {
                    ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(arg))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    "Searching for $arg"
                }
                "media_play" -> { key(audio, KeyEvent.KEYCODE_MEDIA_PLAY); "Play" }
                "media_pause" -> { key(audio, KeyEvent.KEYCODE_MEDIA_PAUSE); "Pause" }
                "media_next" -> { key(audio, KeyEvent.KEYCODE_MEDIA_NEXT); "Next" }
                "media_previous" -> { key(audio, KeyEvent.KEYCODE_MEDIA_PREVIOUS); "Previous" }
                "home" -> {
                    ctx.startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); "Home"
                }
                "back" -> needA11y { it.global(AccessibilityService.GLOBAL_ACTION_BACK); "Back" }
                "recents" -> needA11y { it.global(AccessibilityService.GLOBAL_ACTION_RECENTS); "Recent apps" }
                "click_text" -> needA11y { if (it.clickText(arg)) "Tapped $arg" else "I couldn't find \"$arg\" on screen" }
                "broadcast" -> {
                    val parts = arg.split("|")
                    ctx.sendBroadcast(Intent(parts[0].trim()).apply { parts.getOrNull(1)?.trim()?.takeIf { it.isNotEmpty() }?.let { setPackage(it) } })
                    "Broadcast sent"
                }
                "say" -> arg
                else -> "I can't do \"$action\""
            }
        } catch (e: ActivityNotFoundException) { "No app found for that" } catch (e: Exception) { "Failed: ${e.message}" }
    }

    private fun needA11y(f: (A11yService) -> String): String {
        val s = A11yService.instance ?: return "Turn on accessibility in Assistant settings to do that"
        return f(s)
    }

    private fun openApp(ctx: Context, name: String): String {
        val pm = ctx.packageManager
        val q = Macros.norm(name)
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { Triple(it.activityInfo.packageName, it.loadLabel(pm).toString(), Macros.norm(it.loadLabel(pm).toString())) }
        val hit = apps.firstOrNull { it.third == q } ?: apps.firstOrNull { it.third.contains(q) || (q.contains(it.third) && it.third.length > 2) }
            ?: return "I couldn't find an app called $name"
        val i = pm.getLaunchIntentForPackage(hit.first) ?: return "I can't open ${hit.second}"
        ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "Opening ${hit.second}"
    }

    private fun navigate(ctx: Context, place: String): String {
        if (place.isBlank()) return "Where to?"
        val pm = ctx.packageManager
        val a = Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(place))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val b = Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(place))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return when {
            a.resolveActivity(pm) != null -> { ctx.startActivity(a); "Navigating to $place" }
            b.resolveActivity(pm) != null -> { ctx.startActivity(b); "Showing $place" }
            else -> "No navigation app found"
        }
    }
}
