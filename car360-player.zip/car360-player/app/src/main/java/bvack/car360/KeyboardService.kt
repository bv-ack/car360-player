package bvack.car360

import android.Manifest
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat

/** Half-screen keyboard panel. It sits on the left or right and leaves the other half of the screen usable. */
class KeyboardService : InputMethodService() {
    private lateinit var prefs: SharedPreferences
    private var layouts: List<KbLayout> = emptyList()
    private var layout: KbLayout? = null
    private var root: FrameLayout? = null
    private var panel: LinearLayout? = null
    private var micBtn: TextView? = null
    private var shiftBtn: TextView? = null
    private val letterKeys = ArrayList<Pair<TextView, String>>()
    private var symbols = false
    private var shiftState = 0 // 0 off, 1 next letter, 2 caps lock
    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private val pending = HashMap<String, Int>()
    private var density = 1f

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences("kb", MODE_PRIVATE)
        density = resources.displayMetrics.density
    }

    override fun onEvaluateFullscreenMode() = false

    override fun onCreateInputView(): View {
        val r = FrameLayout(this)
        root = r
        build()
        return r
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        if (!restarting) { symbols = false; shiftState = 0 }
        layouts = KbLayouts.loadAll(this)
        layout = layouts.firstOrNull { it.id == prefs.getString("layout", "en") } ?: layouts.firstOrNull()
        layout?.let { if (prefs.getBoolean("adaptive", false)) Adaptive.maybeResort(this, it) }
        build()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        super.onFinishInputView(finishingInput)
        flush()
        stopVoice()
    }

    override fun onDestroy() { stopVoice(); super.onDestroy() }

    // Keep the app below at full size and let touches outside the panel reach it.
    override fun onComputeInsets(outInsets: InputMethodService.Insets) {
        super.onComputeInsets(outInsets)
        val p = panel ?: return
        if (prefs.getString("mode", "over") != "over" || p.width == 0) return
        val full = window?.window?.decorView?.height?.takeIf { it > 0 } ?: root?.height ?: return
        val loc = IntArray(2)
        p.getLocationInWindow(loc)
        outInsets.contentTopInsets = full
        outInsets.visibleTopInsets = full
        outInsets.touchableInsets = InputMethodService.Insets.TOUCHABLE_INSETS_REGION
        outInsets.touchableRegion.set(loc[0], loc[1], loc[0] + p.width, loc[1] + p.height)
    }

    // ---------- building the panel ----------

    private fun rounded(c: Int) = GradientDrawable().apply { setColor(c); cornerRadius = 10 * density }

    private fun keyView(label: String, sp: Float, bg: Int = 0xFF3C4043.toInt()) = TextView(this).apply {
        text = label; gravity = Gravity.CENTER; setTextColor(Color.WHITE); textSize = sp
        background = rounded(bg); isClickable = true
    }

    private fun LinearLayout.put(v: View, weight: Float) {
        val m = (3 * density).toInt()
        addView(v, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, weight).apply { setMargins(m, m, m, m) })
    }

    private fun build() {
        val r = root ?: return
        val l = layout ?: return
        r.removeAllViews(); letterKeys.clear()
        val dm = resources.displayMetrics
        val w = (dm.widthPixels * prefs.getInt("widthPct", 50) / 100f).toInt()
        val h = (dm.heightPixels * prefs.getInt("heightPct", 75) / 100f).toInt()
        val right = prefs.getString("side", "left") == "right"
        val p = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xF0202124.toInt()) }
        panel = p
        r.addView(p, FrameLayout.LayoutParams(w, h, (if (right) Gravity.END else Gravity.START) or Gravity.BOTTOM))

        fun addRow(weight: Float) = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            .also { p.addView(it, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, weight)) }

        val rows = if (symbols) l.symbols else Adaptive.apply(this, l).takeIf { prefs.getBoolean("adaptive", false) } ?: l.letters
        val rowDp = h / density / (rows.size + 2.8f)
        val sp = (rowDp * 0.36f).coerceIn(14f, 30f)

        // top bar: big mic button, small utility buttons
        val top = addRow(1.5f)
        val mic = keyView("Mic: tap to speak", sp, 0xFF1A73E8.toInt()).also { micBtn = it }
        mic.setOnClickListener { haptic(it); startVoice() }
        top.put(mic, 5f)
        for ((label, act) in listOf<Pair<String, () -> Unit>>(
            "Lang" to { nextLayout() }, "Flip" to { flipSide() }, "Hide" to { requestHideSelf(0) }
        )) {
            val b = keyView(label, sp * 0.65f)
            b.setOnClickListener { haptic(it); act() }
            top.put(b, 1.3f)
        }

        // key rows
        for (row in rows) {
            val rv = addRow(1f)
            for (k in row) {
                val tv = keyView(labelOf(k), sp)
                tv.setOnClickListener { haptic(it); typeKey(k) }
                if (!symbols) letterKeys += Pair(tv, k)
                rv.put(tv, 1f)
            }
        }

        // bottom row
        val bot = addRow(1f)
        val shift = keyView(shiftLabel(), sp * 0.7f).also { shiftBtn = it }
        shift.setOnClickListener { haptic(it); shiftState = (shiftState + 1) % 3; refreshLabels() }
        if (!symbols) bot.put(shift, 1.4f)
        val sym = keyView(if (symbols) "ABC" else "123", sp * 0.7f)
        sym.setOnClickListener { haptic(it); symbols = !symbols; build() }
        bot.put(sym, 1.4f)
        val space = keyView(l.name, sp * 0.7f)
        space.setOnClickListener { haptic(it); currentInputConnection?.commitText(" ", 1) }
        bot.put(space, 4f)
        val del = keyView("Del", sp * 0.7f)
        del.setOnTouchListener { v, e -> deleteTouch(v, e) }
        bot.put(del, 1.4f)
        val enter = keyView("Enter", sp * 0.7f, 0xFF1A73E8.toInt())
        enter.setOnClickListener { haptic(it); pressEnter() }
        bot.put(enter, 1.5f)
    }

    private fun haptic(v: View) { v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP) }

    private fun shiftLabel() = when (shiftState) {
        1 -> "Shift"
        2 -> "CAPS"
        else -> "shift"
    }

    private fun labelOf(k: String): String {
        val l = layout ?: return k
        return if (!symbols && shiftState > 0) l.shiftMap[k] ?: k.uppercase() else k
    }

    private fun refreshLabels() {
        letterKeys.forEach { (tv, k) -> tv.text = labelOf(k) }
        shiftBtn?.text = shiftLabel()
    }

    // ---------- typing ----------

    private fun typeKey(k: String) {
        val text = labelOf(k)
        currentInputConnection?.commitText(text, 1)
        if (!symbols && k.isNotEmpty() && Character.isLetter(k.codePointAt(0))) {
            pending[k] = (pending[k] ?: 0) + 1
            if (pending.values.sum() >= 25) flush()
        }
        if (shiftState == 1) { shiftState = 0; refreshLabels() }
    }

    private fun flush() {
        val l = layout ?: return
        if (prefs.getBoolean("adaptive", false)) Adaptive.add(this, l, pending)
        pending.clear()
    }

    private fun pressEnter() {
        val ei = currentInputEditorInfo
        val action = (ei?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION
        if (ei != null && (ei.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) == 0 &&
            action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED
        ) currentInputConnection?.performEditorAction(action)
        else sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
    }

    private val repeatDel = object : Runnable {
        override fun run() { sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL); handler.postDelayed(this, 60) }
    }

    private fun deleteTouch(v: View, e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { haptic(v); sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL); handler.postDelayed(repeatDel, 400) }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> handler.removeCallbacks(repeatDel)
        }
        return true
    }

    private fun nextLayout() {
        if (layouts.size < 2) { Toast.makeText(this, "Only one layout installed", Toast.LENGTH_SHORT).show(); return }
        flush()
        val i = layouts.indexOf(layout)
        layout = layouts[(i + 1) % layouts.size]
        prefs.edit().putString("layout", layout!!.id).apply()
        symbols = false; shiftState = 0
        build()
    }

    private fun flipSide() {
        prefs.edit().putString("side", if (prefs.getString("side", "left") == "right") "left" else "right").apply()
        build()
        root?.post { panel?.requestLayout() }
    }

    // ---------- voice typing ----------

    private fun startVoice() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Allow the microphone in the Car360 keyboard settings", Toast.LENGTH_LONG).show()
            startActivity(Intent(this, KeyboardSettingsActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "No speech recognition service on this device", Toast.LENGTH_LONG).show(); return
        }
        stopVoice()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { micBtn?.text = "Listening..." }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { micBtn?.text = "Working..." }
            override fun onError(error: Int) { micBtn?.text = "Mic: tap to speak" }
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onPartialResults(partialResults: Bundle?) {
                partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { micBtn?.text = it }
            }
            override fun onResults(results: Bundle?) {
                micBtn?.text = "Mic: tap to speak"
                results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    ?.let { currentInputConnection?.commitText("$it ", 1) }
            }
        })
        r.startListening(
            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, layout?.voiceLocale ?: "en-US")
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        )
    }

    private fun stopVoice() {
        try { recognizer?.destroy() } catch (_: Exception) {}
        recognizer = null
        micBtn?.text = "Mic: tap to speak"
    }
}
