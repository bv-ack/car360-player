package bvack.car360

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** A keyboard layout loaded from a JSON file (see LAYOUTS.md). Keys are plain strings. */
class KbLayout(
    val id: String, val name: String, val voiceLocale: String,
    val letters: List<List<String>>, val shift: List<List<String>>?, val symbols: List<List<String>>
) {
    /** Maps each letter key to what it types when Shift is on. */
    val shiftMap: Map<String, String> = HashMap<String, String>().also { m ->
        letters.forEachIndexed { r, row -> row.forEachIndexed { c, k -> m[k] = shift?.get(r)?.get(c) ?: k.uppercase() } }
    }
}

object KbLayouts {
    private fun rows(a: JSONArray): List<List<String>> =
        (0 until a.length()).map { r -> val row = a.getJSONArray(r); (0 until row.length()).map { row.getString(it) } }

    fun parse(json: String): KbLayout {
        val o = JSONObject(json)
        val id = o.getString("id")
        require(Regex("[A-Za-z0-9_-]{1,40}").matches(id)) { "bad id" }
        val l = rows(o.getJSONArray("letters"))
        val sh = o.optJSONArray("shift")?.let { rows(it) }
        val sy = rows(o.getJSONArray("symbols"))
        require(l.isNotEmpty() && l.all { it.isNotEmpty() })
        if (sh != null) require(sh.size == l.size && sh.indices.all { sh[it].size == l[it].size })
        return KbLayout(id, o.optString("name", id), o.optString("voice", "en-US"), l, sh, sy)
    }

    fun loadAll(ctx: Context): List<KbLayout> {
        val out = ArrayList<KbLayout>()
        try {
            ctx.assets.list("layouts")?.sorted()?.forEach { f ->
                try { out += parse(ctx.assets.open("layouts/$f").bufferedReader().use { it.readText() }) } catch (_: Exception) {}
            }
        } catch (_: Exception) {}
        File(ctx.filesDir, "layouts").listFiles()?.sortedBy { it.name }?.forEach { f ->
            try { val l = parse(f.readText()); out.removeAll { it.id == l.id }; out += l } catch (_: Exception) {}
        }
        return out
    }

    fun saveUser(ctx: Context, json: String): KbLayout {
        val l = parse(json)
        val dir = File(ctx.filesDir, "layouts").apply { mkdirs() }
        File(dir, "${l.id}.json").writeText(json)
        return l
    }
}

/**
 * Optional adaptive placement: letters you use most drift toward the top-middle of the panel,
 * the least used toward the bottom corners. Only counts per key are stored, never the text, and only on this device.
 */
object Adaptive {
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("kb", Context.MODE_PRIVATE)
    private fun isLetterKey(k: String) = k.isNotEmpty() && Character.isLetter(k.codePointAt(0))

    private fun slots(l: KbLayout): List<Pair<Int, Int>> =
        l.letters.flatMapIndexed { r, row -> row.indices.filter { isLetterKey(row[it]) }.map { Pair(r, it) } }

    private fun baseOrder(l: KbLayout) = slots(l).map { l.letters[it.first][it.second] }

    private fun current(ctx: Context, l: KbLayout): List<String> {
        val base = baseOrder(l)
        val s = prefs(ctx).getString("arr_${l.id}", null) ?: return base
        return try {
            val a = JSONArray(s)
            val list = (0 until a.length()).map { a.getString(it) }
            if (list.size == base.size && list.toSet() == base.toSet()) list else base
        } catch (_: Exception) { base }
    }

    /** The letter rows with the learned arrangement applied. */
    fun apply(ctx: Context, l: KbLayout): List<List<String>> {
        val cur = current(ctx, l)
        val rows = l.letters.map { it.toMutableList() }
        slots(l).forEachIndexed { i, (r, c) -> rows[r][c] = cur[i] }
        return rows
    }

    private fun counts(ctx: Context, l: KbLayout): JSONObject =
        try { JSONObject(prefs(ctx).getString("use_${l.id}", "{}")!!) } catch (_: Exception) { JSONObject() }

    fun add(ctx: Context, l: KbLayout, pending: Map<String, Int>) {
        if (pending.isEmpty()) return
        val c = counts(ctx, l)
        var n = 0
        for ((k, v) in pending) { c.put(k, c.optInt(k, 0) + v); n += v }
        prefs(ctx).edit().putString("use_${l.id}", c.toString()).putInt("since_${l.id}", prefs(ctx).getInt("since_${l.id}", 0) + n).apply()
    }

    fun reset(ctx: Context) {
        val e = prefs(ctx).edit()
        prefs(ctx).all.keys.filter { it.startsWith("use_") || it.startsWith("arr_") || it.startsWith("since_") }.forEach { e.remove(it) }
        e.apply()
    }

    /** Moves at most three letters per call, so the layout changes slowly. Call between typing sessions. */
    fun maybeResort(ctx: Context, l: KbLayout) {
        if (prefs(ctx).getInt("since_${l.id}", 0) < 150) return
        val sl = slots(l)
        val rowsN = l.letters.size
        val rank = sl.indices.sortedBy { i ->
            val (r, c) = sl[i]
            val x = (c + 0.5f) / l.letters[r].size - 0.5f
            val y = 1.3f * (r + 0.5f) / rowsN
            x * x + y * y // distance from the top-middle
        }
        val cnt = counts(ctx, l)
        val base = baseOrder(l)
        val byUse = base.sortedWith(compareByDescending<String> { cnt.optInt(it, 0) }.thenBy { base.indexOf(it) })
        val desired = MutableList(base.size) { "" }
        rank.forEachIndexed { i, slot -> desired[slot] = byUse[i] }
        val cur = current(ctx, l).toMutableList()
        var moves = 0
        for (slot in rank) {
            if (moves >= 3) break
            if (cur[slot] != desired[slot]) {
                val t = cur.indexOf(desired[slot])
                val tmp = cur[slot]; cur[slot] = cur[t]; cur[t] = tmp
                moves++
            }
        }
        prefs(ctx).edit().putString("arr_${l.id}", JSONArray(cur).toString()).putInt("since_${l.id}", 0).apply()
    }
}
