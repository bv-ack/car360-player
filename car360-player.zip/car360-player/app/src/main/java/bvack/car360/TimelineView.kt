package bvack.car360

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View

/** One continuous timeline for a whole day. Orange ticks mark gaps between clips (car off). */
class TimelineView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {
    var onSeek: ((Long) -> Unit)? = null
    private var total = 0L
    private var pos = 0L
    private var marks: List<Pair<Long, String>> = emptyList()
    private var rs = -1L
    private var re = -1L
    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    fun setData(total: Long, marks: List<Pair<Long, String>>) {
        this.total = total; this.marks = marks; pos = 0; rs = -1; re = -1; invalidate()
    }
    fun update(total: Long, marks: List<Pair<Long, String>>) { this.total = total; this.marks = marks; invalidate() }
    fun setPos(v: Long) { pos = v; invalidate() }
    fun setRange(a: Long, b: Long) { rs = a; re = b; invalidate() }

    private fun x(v: Long): Float {
        val pad = 16 * d
        return pad + (width - 2 * pad) * (if (total > 0) v.toFloat() / total else 0f)
    }

    override fun onDraw(c: Canvas) {
        val cy = height * 0.62f
        val h = 10 * d
        p.style = Paint.Style.FILL
        p.color = Color.parseColor("#555555")
        c.drawRect(x(0), cy - h / 2, x(total), cy + h / 2, p)
        if (rs >= 0) {
            p.color = Color.parseColor("#2E7DFF")
            c.drawRect(x(rs), cy - h, x(if (re >= 0) re else rs + 1), cy + h, p)
        }
        p.color = Color.parseColor("#DDDDDD")
        c.drawRect(x(0), cy - h / 2, x(pos), cy + h / 2, p)
        p.color = Color.parseColor("#FF9800")
        p.textSize = 11 * d
        p.strokeWidth = 3 * d
        for ((m, label) in marks) {
            c.drawLine(x(m), cy - h * 1.6f, x(m), cy + h * 1.6f, p)
            c.drawText(label, x(m) + 3 * d, cy - h * 1.7f, p)
        }
        p.color = Color.WHITE
        c.drawCircle(x(pos), cy, 9 * d, p)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (total <= 0) return false
        if (e.action == MotionEvent.ACTION_DOWN || e.action == MotionEvent.ACTION_MOVE) {
            parent?.requestDisallowInterceptTouchEvent(true)
            val pad = 16 * d
            val f = ((e.x - pad) / (width - 2 * pad)).coerceIn(0f, 1f)
            pos = (total * f).toLong()
            onSeek?.invoke(pos)
            invalidate()
            return true
        }
        return true
    }
}
