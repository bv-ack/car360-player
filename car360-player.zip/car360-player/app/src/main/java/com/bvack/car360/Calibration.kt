package com.bvack.car360

import org.json.JSONArray
import org.json.JSONObject

/**
 * EXPERIMENTAL. Exports/imports a calibration template for a future bird's-eye stitcher.
 * Values are placeholders; the stitcher does not use them yet.
 * Coordinates are normalised to each tile (0..1). Distortion uses a fisheye model (k1..k4).
 */
object Calibration {
    private val tiles = listOf("TL", "TR", "BL", "BR")

    fun template(): String {
        val cams = JSONArray()
        tiles.forEachIndexed { i, t ->
            cams.put(JSONObject().apply {
                put("name", "cam$i")          // rename to front/rear/left/right
                put("tile", t)
                put("cx", 0.5); put("cy", 0.5)  // optical centre
                put("focal", 0.35)              // focal length / tile width
                put("k", JSONArray(listOf(0.0, 0.0, 0.0, 0.0)))
                put("groundPoints", JSONArray()) // [{"u":..,"v":..,"x_m":..,"y_m":..}, ...]
            })
        }
        return JSONObject().apply {
            put("version", 1)
            put("layout", "2x2")
            put("vehicle", JSONObject().put("length_m", 4.5).put("width_m", 1.8))
            put("birdseye", JSONObject().put("metres_per_pixel", 0.01).put("width_px", 800).put("height_px", 800))
            put("cameras", cams)
        }.toString(2)
    }

    /** Returns a short summary, or throws if the JSON is not a valid calibration file. */
    fun summarise(json: String): String {
        val o = JSONObject(json)
        val n = o.getJSONArray("cameras").length()
        return "Calibration v${o.optInt("version")}: $n cameras, layout ${o.optString("layout")}"
    }
}
