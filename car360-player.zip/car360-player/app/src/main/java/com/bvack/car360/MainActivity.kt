package com.bvack.car360

import android.Manifest
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Rect
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.Button
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.effect.Crop
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.ui.PlayerView
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {
    companion object { const val GAP_MS = 120_000L } // gaps longer than this get a tag

    private lateinit var player: ExoPlayer
    private lateinit var playerView: PlayerView
    private lateinit var status: TextView
    private lateinit var timeLabel: TextView
    private lateinit var info: TextView
    private lateinit var timeline: TimelineView
    private lateinit var calendarPanel: View
    private lateinit var playerPanel: View
    private lateinit var calGrid: LinearLayout
    private lateinit var monthLabel: TextView
    private var viewMonth: Calendar = Calendar.getInstance()
    private val handler = Handler(Looper.getMainLooper())

    // all footage
    private var byDay: Map<String, List<Clip>> = emptyMap()
    private var selectedDay: String? = null
    // the day being played
    private var dayClips: List<Clip> = emptyList()
    private var durs = LongArray(0)
    private var cum = LongArray(0)      // start of each clip on the day timeline
    private var gapBefore = LongArray(0)
    private var total = 0L
    private var rangeStart = -1L
    private var rangeEnd = -1L

    private var quadrant = -1 // -1 = full 2x2 grid, 0..3 = TL, TR, BL, BR
    private var videoW = 0
    private var videoH = 0
    private var pixelRatio = 1f
    private var pendingPath: String? = null
    private var exporting = false
    private var durReady = false
    private var durDone = 0
    private var durGen = 0
    private val pool: ExecutorService = Executors.newFixedThreadPool(4) { r -> Thread(r).apply { isDaemon = true } }

    private val dayFmt = SimpleDateFormat("yyyyMMdd", Locale.US)
    private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.US)
    private val fileFmt = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US)

    private val pickFolder = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            getPreferences(MODE_PRIVATE).edit().putString("tree", uri.toString()).apply()
            scan { ClipScanner.scanTree(this, uri) }
        }
    }
    private val askPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        pendingPath?.let { p -> scan { ClipScanner.scanPath(p) } }
    }
    private val exportCal = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            contentResolver.openOutputStream(uri)?.use { it.write(Calibration.template().toByteArray()) }
            toast("Calibration template saved")
        }
    }
    private val importCal = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                val text = contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }
                toast(Calibration.summarise(text))
            } catch (e: Exception) { toast("Not a valid calibration file") }
        }
    }
    private val exportPick = registerForActivityResult(ActivityResultContracts.CreateDocument("video/mp4")) { uri ->
        if (uri != null) runExport(uri)
    }

    private val tick = object : Runnable {
        override fun run() {
            if (playerPanel.visibility == View.VISIBLE && dayClips.isNotEmpty()) {
                val i = player.currentMediaItemIndex.coerceIn(dayClips.indices)
                val p = player.currentPosition.coerceIn(0L, durs[i].coerceAtLeast(1L))
                timeline.setPos(cum[i] + p)
                var t = "${timeFmt.format(Date(dayClips[i].startMs + p))}   |   ${hms(cum[i] + p)} / ${hms(total)}"
                if (rangeStart >= 0) t += "   |   range ${hms(rangeStart)} - ${if (rangeEnd >= 0) hms(rangeEnd) else "?"}"
                timeLabel.text = t
            }
            handler.postDelayed(this, 250)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        playerView = findViewById(R.id.player)
        status = findViewById(R.id.status)
        timeLabel = findViewById(R.id.timeLabel)
        info = findViewById(R.id.info)
        timeline = findViewById(R.id.timeline)
        calendarPanel = findViewById(R.id.calendarPanel)
        playerPanel = findViewById(R.id.playerPanel)
        calGrid = findViewById(R.id.calGrid)
        monthLabel = findViewById(R.id.monthLabel)
        findViewById<Button>(R.id.btnPrevMonth).setOnClickListener { viewMonth.add(Calendar.MONTH, -1); renderMonth() }
        findViewById<Button>(R.id.btnNextMonth).setOnClickListener { viewMonth.add(Calendar.MONTH, 1); renderMonth() }
        playerView.keepScreenOn = true
        playerView.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> applyZoom() }

        findViewById<Button>(R.id.btnFolder).setOnClickListener { chooseFolder() }
        findViewById<Button>(R.id.btnPlayDay).setOnClickListener { playDay() }
        timeline.onSeek = { pos -> seekGlobal(pos) }

        player = ExoPlayer.Builder(this).build()
        playerView.player = player
        player.addListener(object : Player.Listener {
            override fun onVideoSizeChanged(size: VideoSize) {
                videoW = size.width; videoH = size.height
                pixelRatio = if (size.pixelWidthHeightRatio > 0f) size.pixelWidthHeightRatio else 1f
                applyZoom()
            }
            override fun onMediaItemTransition(item: MediaItem?, reason: Int) {
                val i = player.currentMediaItemIndex
                if (dayClips.isNotEmpty() && i in dayClips.indices && gapBefore[i] > GAP_MS) {
                    status.text = "Resumed after a gap of ${gapText(gapBefore[i])} (car off?)"
                    handler.postDelayed({ updateStatus() }, 6000)
                } else updateStatus()
            }
            override fun onPlayerError(error: PlaybackException) { status.text = "Playback error: ${error.errorCodeName}" }
        })

        val bar = findViewById<LinearLayout>(R.id.bar)
        fun btn(label: String, action: () -> Unit) {
            bar.addView(Button(this).apply {
                text = label; textSize = 18f; setOnClickListener { action() }
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.MATCH_PARENT)
            })
        }
        btn("Calendar") { showCalendar() }
        btn("Play/Pause") { if (player.isPlaying) player.pause() else player.play() }
        btn("-30s") { seekGlobal((globalPos() - 30_000).coerceAtLeast(0)) }
        btn("+30s") { seekGlobal((globalPos() + 30_000).coerceAtMost(total)) }
        btn("Go to time") { pickTime() }
        btn("Full") { setQuadrant(-1) }
        btn("TL") { setQuadrant(0) }
        btn("TR") { setQuadrant(1) }
        btn("BL") { setQuadrant(2) }
        btn("BR") { setQuadrant(3) }
        btn("Set start") { if (!durReady) { toast("Still reading clip lengths ($durDone/${dayClips.size})"); return@btn }; rangeStart = globalPos(); if (rangeEnd <= rangeStart) rangeEnd = -1; timeline.setRange(rangeStart, rangeEnd) }
        btn("Set end") { if (!durReady) { toast("Still reading clip lengths ($durDone/${dayClips.size})"); return@btn }; rangeEnd = globalPos(); timeline.setRange(rangeStart, rangeEnd) }
        btn("Export MP4") { startExport() }
        btn("Calib export") { exportCal.launch("car360_calibration.json") }
        btn("Calib import") { importCal.launch(arrayOf("application/json", "text/*", "*/*")) }

        handler.post(tick)
        getPreferences(MODE_PRIVATE).getString("tree", null)?.let { s ->
            scan { try { ClipScanner.scanTree(this, Uri.parse(s)) } catch (_: Exception) { emptyList() } }
        }
    }

    // ---------- folder / calendar ----------

    private fun chooseFolder() {
        try {
            pickFolder.launch(null)
        } catch (e: ActivityNotFoundException) {
            val input = EditText(this).apply { setText("/storage") }
            AlertDialog.Builder(this).setTitle("Folder path").setView(input)
                .setPositiveButton("Scan") { _, _ ->
                    val path = input.text.toString()
                    pendingPath = path
                    if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)
                        scan { ClipScanner.scanPath(path) }
                    else askPermission.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
                }.show()
        }
    }

    private fun scan(block: () -> List<Clip>) {
        info.text = "Scanning..."
        Thread {
            val list = try { block() } catch (e: Exception) { emptyList() }
            runOnUiThread { setClips(list) }
        }.start()
    }

    private fun startOfDay(ms: Long): Long = Calendar.getInstance().apply {
        timeInMillis = ms; set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    private fun setClips(list: List<Clip>) {
        byDay = list.groupBy { dayFmt.format(Date(it.startMs)) }
        if (list.isEmpty()) { info.text = "No video files found. Choose a folder."; return }
        val last = startOfDay(list.last().startMs)
        viewMonth = Calendar.getInstance().apply { timeInMillis = last; set(Calendar.DAY_OF_MONTH, 1) }
        selectedDay = dayFmt.format(Date(last))
        updateInfo()
    }

    private fun updateInfo() {
        renderMonth()
        val l = byDay[selectedDay]
        info.text = if (l == null) "No recordings on this day"
        else "${l.size} clips\n${timeFmt.format(Date(l.first().startMs))} - ${timeFmt.format(Date(l.last().startMs))}\n(${byDay.size} days in folder)"
    }

    private fun renderMonth() {
        monthLabel.text = SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(viewMonth.time)
        calGrid.removeAllViews()
        fun row(w: Float) = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, w)
        }
        fun cell(label: String, fg: Int, bg: Int, bold: Boolean) = TextView(this).apply {
            text = label; setTextColor(fg); setBackgroundColor(bg); gravity = Gravity.CENTER; textSize = 18f
            if (bold) setTypeface(typeface, Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f).apply { setMargins(2, 2, 2, 2) }
        }
        val hdr = row(0.6f)
        listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun").forEach {
            hdr.addView(cell(it, Color.parseColor("#AAAAAA"), Color.TRANSPARENT, false))
        }
        calGrid.addView(hdr)
        val cal = viewMonth.clone() as Calendar
        cal.set(Calendar.DAY_OF_MONTH, 1)
        val offset = (cal.get(Calendar.DAY_OF_WEEK) + 5) % 7 // Monday first
        val days = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
        var day = 1 - offset
        for (r in 0 until 6) {
            val rw = row(1f)
            for (c in 0 until 7) {
                if (day in 1..days) {
                    cal.set(Calendar.DAY_OF_MONTH, day)
                    val key = dayFmt.format(cal.time)
                    val has = byDay.containsKey(key)
                    val sel = key == selectedDay
                    val tv = cell(
                        day.toString(),
                        if (sel) Color.BLACK else if (has) Color.WHITE else Color.parseColor("#777777"),
                        if (sel) Color.parseColor("#FF9800") else if (has) Color.parseColor("#2E7DFF") else Color.parseColor("#2A2A2A"),
                        has
                    )
                    if (has) tv.setOnClickListener { selectedDay = key; updateInfo() }
                    rw.addView(tv)
                } else rw.addView(cell("", Color.TRANSPARENT, Color.TRANSPARENT, false))
                day++
            }
            calGrid.addView(rw)
        }
    }

    private fun showCalendar() { player.pause(); playerPanel.visibility = View.GONE; calendarPanel.visibility = View.VISIBLE }
    private fun showPlayer() { calendarPanel.visibility = View.GONE; playerPanel.visibility = View.VISIBLE }
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (playerPanel.visibility == View.VISIBLE) showCalendar() else super.onBackPressed() }

    // ---------- day timeline ----------

    private fun durationMs(uri: Uri): Long {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(this, uri)
            r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } catch (e: Exception) { 0L } finally { r.release() }
    }

    private fun playDay() {
        val list = byDay[selectedDay]
        if (list == null) { toast("No recordings on this day"); return }
        startDay(list)
    }

    /** Guess clip lengths from the gap between start times, so playback can begin at once. */
    private fun estimateDurations(list: List<Clip>): LongArray {
        val diffs = (0 until list.size - 1).map { list[it + 1].startMs - list[it].startMs }
            .filter { it in 5_000L..600_000L }.sorted()
        val nominal = if (diffs.isEmpty()) 60_000L else diffs[diffs.size / 2]
        return LongArray(list.size) { i ->
            if (i < list.size - 1) minOf(list[i + 1].startMs - list[i].startMs, nominal).coerceAtLeast(1000L) else nominal
        }
    }

    private fun recompute(reset: Boolean) {
        val n = dayClips.size
        cum = LongArray(n); gapBefore = LongArray(n)
        var acc = 0L
        val marks = ArrayList<Pair<Long, String>>()
        for (i in 0 until n) {
            cum[i] = acc; acc += durs[i]
            if (i > 0) {
                gapBefore[i] = (dayClips[i].startMs - (dayClips[i - 1].startMs + durs[i - 1])).coerceAtLeast(0)
                if (gapBefore[i] > GAP_MS) marks += Pair(cum[i], gapText(gapBefore[i]))
            }
        }
        total = acc
        if (reset) timeline.setData(total, marks) else timeline.update(total, marks)
    }

    private fun startDay(list: List<Clip>) {
        dayClips = list
        durs = estimateDurations(list)
        durReady = false; durDone = 0
        val gen = ++durGen
        rangeStart = -1; rangeEnd = -1
        recompute(true)
        updateInfo()
        player.setMediaItems(list.map { MediaItem.fromUri(it.uri) })
        player.prepare(); player.play()
        quadrant = -1; applyZoom()
        updateStatus(); showPlayer()
        // Read the real lengths in the background (4 at a time); the timeline sharpens as they arrive.
        for (i in list.indices) {
            pool.execute {
                val d = durationMs(list[i].uri)
                runOnUiThread {
                    if (gen != durGen) return@runOnUiThread
                    if (d > 0) durs[i] = d
                    durDone++
                    if (durDone == list.size) { durReady = true; recompute(false); updateStatus() }
                    else if (durDone % 5 == 0) { recompute(false); updateStatus() }
                }
            }
        }
    }

    private fun globalPos(): Long {
        if (dayClips.isEmpty()) return 0
        val i = player.currentMediaItemIndex.coerceIn(dayClips.indices)
        return cum[i] + player.currentPosition.coerceIn(0L, durs[i])
    }

    private fun clipAt(pos: Long): Int = cum.indexOfLast { it <= pos }.coerceAtLeast(0)

    private fun seekGlobal(pos: Long) {
        if (dayClips.isEmpty()) return
        val i = clipAt(pos)
        player.seekTo(i, (pos - cum[i]).coerceAtLeast(0))
    }

    private fun updateStatus() {
        if (dayClips.isEmpty()) return
        val i = player.currentMediaItemIndex.coerceIn(dayClips.indices)
        status.text = "${i + 1}/${dayClips.size}  ${dayClips[i].name}" +
            (if (durReady) "" else "   (reading lengths $durDone/${dayClips.size})")
    }

    private fun pickTime() {
        if (dayClips.isEmpty()) return
        val cur = Calendar.getInstance().apply { timeInMillis = dayClips[player.currentMediaItemIndex.coerceIn(dayClips.indices)].startMs }
        TimePickerDialog(this, { _, h, m -> jumpTo(h, m) }, cur.get(Calendar.HOUR_OF_DAY), cur.get(Calendar.MINUTE), true).show()
    }

    private fun jumpTo(h: Int, m: Int) {
        val base = dayClips[player.currentMediaItemIndex.coerceIn(dayClips.indices)].startMs
        val target = Calendar.getInstance().apply {
            timeInMillis = base
            set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, m); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        val i = dayClips.indexOfLast { it.startMs <= target }.coerceAtLeast(0)
        player.seekTo(i, (target - dayClips[i].startMs).coerceIn(0L, durs[i]))
    }

    // ---------- zoom ----------

    private fun setQuadrant(q: Int) { quadrant = q; applyZoom() }

    private fun applyZoom() {
        val w = playerView.width
        val h = playerView.height
        if (quadrant < 0 || w == 0 || h == 0 || videoW == 0 || videoH == 0) {
            playerView.scaleX = 1f; playerView.scaleY = 1f; playerView.clipBounds = null
            return
        }
        val aspect = videoW * pixelRatio / videoH
        var vw = w.toFloat()
        var vh = vw / aspect
        if (vh > h) { vh = h.toFloat(); vw = vh * aspect }
        val l = (w - vw) / 2f
        val t = (h - vh) / 2f
        val r = l + vw
        val b = t + vh
        playerView.clipBounds = Rect(l.toInt(), t.toInt(), r.toInt(), b.toInt())
        playerView.pivotX = if (quadrant % 2 == 0) l else r
        playerView.pivotY = if (quadrant < 2) t else b
        playerView.scaleX = 2f
        playerView.scaleY = 2f
    }

    // ---------- export ----------

    private fun startExport() {
        if (exporting) { toast("Export already running"); return }
        if (!durReady) { toast("Still reading clip lengths"); return }
        if (rangeStart < 0 || rangeEnd <= rangeStart) { toast("Set a start and an end first"); return }
        val i = clipAt(rangeStart)
        val wall = dayClips[i].startMs + (rangeStart - cum[i])
        exportPick.launch("car360_${fileFmt.format(Date(wall))}.mp4")
    }

    private fun runExport(dest: Uri) {
        val effects = if (quadrant >= 0) {
            val left = if (quadrant % 2 == 0) -1f else 0f
            val bottom = if (quadrant < 2) 0f else -1f
            Effects(emptyList(), listOf(Crop(left, left + 1f, bottom, bottom + 1f)))
        } else Effects.EMPTY
        val items = ArrayList<EditedMediaItem>()
        for (i in dayClips.indices) {
            val s = cum[i]; val e = cum[i] + durs[i]
            if (e <= rangeStart || s >= rangeEnd) continue
            val from = (rangeStart - s).coerceAtLeast(0L)
            val to = (rangeEnd - s).coerceAtMost(durs[i])
            val mi = MediaItem.Builder().setUri(dayClips[i].uri)
                .setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder().setStartPositionMs(from).setEndPositionMs(to).build()
                ).build()
            items += EditedMediaItem.Builder(mi).setEffects(effects).build()
        }
        if (items.isEmpty()) { toast("Nothing in that range"); return }
        val tmp = File(cacheDir, "export.mp4").also { it.delete() }
        exporting = true
        player.pause()
        val transformer = Transformer.Builder(this).addListener(object : Transformer.Listener {
            override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                Thread {
                    try {
                        contentResolver.openOutputStream(dest)?.use { out -> tmp.inputStream().use { it.copyTo(out) } }
                        runOnUiThread { exporting = false; status.text = "Export saved"; toast("Export saved") }
                    } catch (e: Exception) {
                        runOnUiThread { exporting = false; toast("Could not write the file: ${e.message}") }
                    }
                }.start()
            }
            override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                exporting = false
                status.text = "Export failed: ${exportException.errorCodeName}"
            }
        }).build()
        transformer.start(Composition.Builder(listOf(EditedMediaItemSequence(items))).build(), tmp.absolutePath)
        val holder = ProgressHolder()
        val poll = object : Runnable {
            override fun run() {
                if (!exporting) return
                if (transformer.getProgress(holder) == Transformer.PROGRESS_STATE_AVAILABLE)
                    status.text = "Exporting... ${holder.progress}% (keep the app open)"
                handler.postDelayed(this, 500)
            }
        }
        handler.post(poll)
    }

    // ---------- helpers ----------

    private fun hms(ms: Long): String {
        val s = ms / 1000
        return "%d:%02d:%02d".format(s / 3600, (s / 60) % 60, s % 60)
    }

    private fun gapText(ms: Long): String {
        val m = ms / 60_000
        return if (m >= 60) "${m / 60}h${"%02d".format(m % 60)}m" else "${m}m"
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    override fun onStop() { super.onStop(); player.pause() }
    override fun onDestroy() { super.onDestroy(); handler.removeCallbacksAndMessages(null); player.release() }
}
