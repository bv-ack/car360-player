package com.bvack.car360

import android.Manifest
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Rect
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var player: ExoPlayer
    private lateinit var playerView: PlayerView
    private lateinit var status: TextView
    private var clips: List<Clip> = emptyList()
    private var quadrant = -1 // -1 = full 2x2 grid, 0..3 = TL, TR, BL, BR
    private var videoW = 0
    private var videoH = 0
    private var pixelRatio = 1f
    private var pendingPath: String? = null
    private val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)

    private val pickFolder = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {}
            getPreferences(MODE_PRIVATE).edit().putString("tree", uri.toString()).apply()
            load(ClipScanner.scanTree(this, uri))
        }
    }
    private val askPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        pendingPath?.let { load(ClipScanner.scanPath(it)) }
    }
    private val exportCal = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            contentResolver.openOutputStream(uri)?.use { it.write(Calibration.template().toByteArray()) }
            toast("Calibration template saved")
        }
    }
    private val importCal = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                val text = contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }
                toast(Calibration.summarise(text))
            } catch (e: Exception) {
                toast("Not a valid calibration file")
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        playerView = findViewById(R.id.player)
        status = findViewById(R.id.status)
        playerView.keepScreenOn = true
        playerView.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> applyZoom() }

        player = ExoPlayer.Builder(this).build()
        playerView.player = player
        player.addListener(object : Player.Listener {
            override fun onVideoSizeChanged(size: VideoSize) {
                videoW = size.width; videoH = size.height
                pixelRatio = if (size.pixelWidthHeightRatio > 0f) size.pixelWidthHeightRatio else 1f
                applyZoom()
            }
            override fun onMediaItemTransition(item: MediaItem?, reason: Int) = updateStatus()
            override fun onPlayerError(error: PlaybackException) {
                status.text = "Playback error: ${error.errorCodeName}"
            }
        })

        val bar = findViewById<LinearLayout>(R.id.bar)
        fun btn(label: String, action: () -> Unit) {
            bar.addView(Button(this).apply { text = label; setOnClickListener { action() } })
        }
        btn("Folder") { chooseFolder() }
        btn("Prev") { player.seekToPreviousMediaItem() }
        btn("Play/Pause") { if (player.isPlaying) player.pause() else player.play() }
        btn("Next") { player.seekToNextMediaItem() }
        btn("Go to time") { pickTime() }
        btn("Full") { setQuadrant(-1) }
        btn("TL") { setQuadrant(0) }
        btn("TR") { setQuadrant(1) }
        btn("BL") { setQuadrant(2) }
        btn("BR") { setQuadrant(3) }
        btn("Calib export") { exportCal.launch("car360_calibration.json") }
        btn("Calib import") { importCal.launch(arrayOf("application/json", "text/*", "*/*")) }

        getPreferences(MODE_PRIVATE).getString("tree", null)?.let {
            try { load(ClipScanner.scanTree(this, Uri.parse(it))) } catch (_: Exception) {}
        }
    }

    private fun chooseFolder() {
        try {
            pickFolder.launch(null)
        } catch (e: ActivityNotFoundException) {
            // Some head units have no system file picker: fall back to typing a path.
            val input = EditText(this).apply { setText("/storage") }
            AlertDialog.Builder(this).setTitle("Folder path").setView(input)
                .setPositiveButton("Scan") { _, _ ->
                    pendingPath = input.text.toString()
                    if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)
                        load(ClipScanner.scanPath(pendingPath!!))
                    else askPermission.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
                }.show()
        }
    }

    private fun load(list: List<Clip>) {
        clips = list
        if (list.isEmpty()) { status.text = "No video files found"; return }
        player.setMediaItems(list.map { MediaItem.fromUri(it.uri) })
        player.prepare()
        player.play()
        updateStatus()
    }

    private fun updateStatus() {
        if (clips.isEmpty()) return
        val i = player.currentMediaItemIndex.coerceIn(clips.indices)
        status.text = "${i + 1}/${clips.size}  ${clips[i].name}  ${fmt.format(Date(clips[i].startMs))}"
    }

    private fun pickTime() {
        if (clips.isEmpty()) return
        val cur = Calendar.getInstance().apply { timeInMillis = clips[player.currentMediaItemIndex.coerceIn(clips.indices)].startMs }
        TimePickerDialog(this, { _, h, m -> jumpTo(h, m) }, cur.get(Calendar.HOUR_OF_DAY), cur.get(Calendar.MINUTE), true).show()
    }

    /** Jumps to a time of day on the same date as the clip now playing. */
    private fun jumpTo(h: Int, m: Int) {
        val cur = clips[player.currentMediaItemIndex.coerceIn(clips.indices)]
        val target = Calendar.getInstance().apply {
            timeInMillis = cur.startMs
            set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, m); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        val idx = clips.indexOfLast { it.startMs <= target }.coerceAtLeast(0)
        player.seekTo(idx, (target - clips[idx].startMs).coerceAtLeast(0))
    }

    private fun setQuadrant(q: Int) { quadrant = q; applyZoom() }

    /** Zooms into one tile of the 2x2 grid by scaling the view about the tile's outer corner. */
    private fun applyZoom() {
        val w = playerView.width
        val h = playerView.height
        if (quadrant < 0 || w == 0 || h == 0 || videoW == 0 || videoH == 0) {
            playerView.scaleX = 1f; playerView.scaleY = 1f; playerView.clipBounds = null
            return
        }
        val aspect = videoW * pixelRatio / videoH
        var vw = w.toFloat()
        var vh = vw / aspect
        if (vh > h) { vh = h.toFloat(); vw = vh * aspect }
        val l = (w - vw) / 2f
        val t = (h - vh) / 2f
        val r = l + vw
        val b = t + vh
        playerView.clipBounds = Rect(l.toInt(), t.toInt(), r.toInt(), b.toInt())
        playerView.pivotX = if (quadrant % 2 == 0) l else r
        playerView.pivotY = if (quadrant < 2) t else b
        playerView.scaleX = 2f
        playerView.scaleY = 2f
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    override fun onStop() { super.onStop(); player.pause() }
    override fun onDestroy() { super.onDestroy(); player.release() }
}
