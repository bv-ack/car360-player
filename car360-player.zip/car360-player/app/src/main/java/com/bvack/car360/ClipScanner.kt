package com.bvack.car360

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import java.io.File
import java.util.GregorianCalendar

data class Clip(val uri: Uri, val name: String, val startMs: Long)

/** Generic scanner: finds video files in a folder tree and orders them by timestamp. */
object ClipScanner {
    private val exts = setOf("mp4", "mov", "mkv", "ts", "avi", "3gp", "m4v")

    // Matches e.g. 2026_1027_143055, 20261027-143055, 2026-10-27_14-30-55
    private val stamp = Regex(
        "(20\\d{2})[-_.]?(\\d{2})[-_.]?(\\d{2})[-_ T.]?(\\d{2})[-_.]?(\\d{2})[-_.]?(\\d{2})"
    )

    fun parseTime(name: String, fallbackMs: Long): Long {
        val m = stamp.find(name) ?: return fallbackMs
        val (y, mo, d, h, mi, s) = m.destructured
        return GregorianCalendar(y.toInt(), mo.toInt() - 1, d.toInt(), h.toInt(), mi.toInt(), s.toInt())
            .timeInMillis
    }

    private fun isVideo(name: String) = name.substringAfterLast('.', "").lowercase() in exts

    fun scanTree(ctx: Context, tree: Uri): List<Clip> {
        val out = ArrayList<Clip>()
        fun walk(dir: DocumentFile) {
            for (f in dir.listFiles()) {
                if (f.isDirectory) walk(f)
                else {
                    val n = f.name ?: continue
                    if (isVideo(n)) out += Clip(f.uri, n, parseTime(n, f.lastModified()))
                }
            }
        }
        DocumentFile.fromTreeUri(ctx, tree)?.let { walk(it) }
        return sort(out)
    }

    fun scanPath(path: String): List<Clip> =
        sort(File(path).walkTopDown().filter { it.isFile && isVideo(it.name) }
            .map { Clip(Uri.fromFile(it), it.name, parseTime(it.name, it.lastModified())) }.toList())

    private fun sort(l: List<Clip>) = l.sortedWith(compareBy({ it.startMs }, { it.name }))
}
