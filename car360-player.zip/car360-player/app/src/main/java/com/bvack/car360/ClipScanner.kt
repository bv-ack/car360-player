package com.bvack.car360

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.GregorianCalendar

data class Clip(val uri: Uri, val name: String, val startMs: Long)

/** Finds video files and orders them by the timestamp in their name (else file date). */
object ClipScanner {
    private val exts = setOf("mp4", "mov", "mkv", "ts", "avi", "3gp", "m4v")
    private val skipDirs = setOf("Android", "LOST.DIR", "System Volume Information", "\$RECYCLE.BIN")

    // Matches e.g. 2026_1027_143055, 20261027-143055, 2026-10-27_14-30-55
    private val stamp = Regex(
        "(20\\d{2})[-_.]?(\\d{2})[-_.]?(\\d{2})[-_ T.]?(\\d{2})[-_.]?(\\d{2})[-_.]?(\\d{2})"
    )

    fun parseTime(name: String, fallbackMs: Long): Long {
        val m = stamp.find(name) ?: return fallbackMs
        val (y, mo, d, h, mi, s) = m.destructured
        return GregorianCalendar(y.toInt(), mo.toInt() - 1, d.toInt(), h.toInt(), mi.toInt(), s.toInt()).timeInMillis
    }

    private fun isVideo(name: String) = name.substringAfterLast('.', "").lowercase() in exts
    private fun sort(l: List<Clip>) = l.sortedWith(compareBy({ it.startMs }, { it.name }))

    /** Fast scan of a folder picked with the system picker: one query per folder, not per file. */
    fun scanTree(ctx: Context, tree: Uri): List<Clip> {
        val out = ArrayList<Clip>()
        val cols = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE, DocumentsContract.Document.COLUMN_LAST_MODIFIED
        )
        fun walk(docId: String, depth: Int) {
            if (depth > 8) return
            val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
            ctx.contentResolver.query(children, cols, null, null, null)?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getString(0) ?: continue
                    val name = c.getString(1) ?: continue
                    if (c.getString(2) == DocumentsContract.Document.MIME_TYPE_DIR) walk(id, depth + 1)
                    else if (isVideo(name)) out += Clip(DocumentsContract.buildDocumentUriUsingTree(tree, id), name, parseTime(name, c.getLong(3)))
                }
            }
        }
        walk(DocumentsContract.getTreeDocumentId(tree), 0)
        return sort(out)
    }

    private fun walkFiles(dir: File, depth: Int, out: MutableList<Clip>) {
        if (depth > 6) return
        val kids = dir.listFiles() ?: return
        for (f in kids) {
            if (f.isDirectory) {
                if (f.name !in skipDirs && !f.name.startsWith(".")) walkFiles(f, depth + 1, out)
            } else if (isVideo(f.name)) out += Clip(Uri.fromFile(f), f.name, parseTime(f.name, f.lastModified()))
        }
    }

    fun scanPath(path: String): List<Clip> {
        val out = ArrayList<Clip>(); walkFiles(File(path), 0, out); return sort(out)
    }

    /** Looks on removable drives (USB sticks, SD cards) for recordings. Needs storage permission. */
    fun scanVolumes(): List<Clip> {
        val roots = ArrayList<File>()
        File("/storage").listFiles()?.filterTo(roots) { it.isDirectory && it.canRead() && it.name != "self" && it.name != "emulated" }
        listOf("/mnt/usb_storage", "/mnt/usbotg", "/mnt/media_rw").map { File(it) }
            .filterTo(roots) { it.isDirectory && it.canRead() }
        val out = ArrayList<Clip>()
        roots.forEach { walkFiles(it, 0, out) }
        return sort(out)
    }

    // ---- cache of the last scan, so the calendar appears instantly ----
    fun saveCache(ctx: Context, list: List<Clip>) {
        try {
            val a = JSONArray()
            list.forEach { a.put(JSONObject().put("u", it.uri.toString()).put("n", it.name).put("t", it.startMs)) }
            File(ctx.filesDir, "clips.json").writeText(a.toString())
        } catch (_: Exception) {}
    }

    fun loadCache(ctx: Context): List<Clip> = try {
        val a = JSONArray(File(ctx.filesDir, "clips.json").readText())
        (0 until a.length()).map { val o = a.getJSONObject(it); Clip(Uri.parse(o.getString("u")), o.getString("n"), o.getLong("t")) }
    } catch (_: Exception) { emptyList() }
}
