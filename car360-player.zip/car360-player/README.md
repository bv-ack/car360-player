# car360-player

Experimental Android player for raw 2x2 car 360 camera recordings (head units).

v0.1: pick a folder (or type a path), play all clips in timestamp order, jump to a time,
zoom into one of the four tiles, export/import an experimental calibration template.
Not yet: MP4 export, bird's-eye stitching.

Build: push to `main` (or Actions > Build APK > Run workflow), then download the
`car360-player-debug` artifact and install `app-debug.apk` (allow "unknown sources").

Clip order comes from a timestamp in the filename (e.g. 2026_1027_143055), else file date.
