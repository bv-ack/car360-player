# car360-player

Experimental Android player for raw 2x2 car 360 camera recordings (head units).

v0.4: calendar, day timeline with gap tags, range export to MP4, bird's-eye view with manual lens/pose tuning (imports calibinfo.lua).

Build: push to `main` (or Actions > Build APK > Run workflow), then download the
`car360-player-debug` artifact and install `app-debug.apk` (allow "unknown sources").

Clip order comes from a timestamp in the filename (e.g. 2026_1027_143055), else file date.
