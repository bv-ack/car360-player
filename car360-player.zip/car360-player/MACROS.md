# Assistant macros

The assistant matches what you say against phrases in a JSON file. Load your own in
**Assistant settings > Load a macros file**; "Back to the default macros" restores the built-in list
(`app/src/main/assets/macros.json`). The first macro that matches wins, so put specific phrases before general ones.

```json
{
  "macros": [
    { "say": ["volume up", "louder"], "action": "volume_up" },
    { "say": ["set volume to {n}", "volume {n}"], "action": "volume_set", "arg": "{n}" },
    { "say": ["navigate to {place}"], "action": "navigate", "arg": "{place}" },
    { "say": ["radio on"], "action": "broadcast", "arg": "com.example.RADIO_ON|com.example.radio", "confirm": false }
  ]
}
```

- `say`: phrases in lower case. `{name}` captures the rest of the sentence (use lower-case names).
- `action`: one of `volume_up`, `volume_down`, `volume_set`, `mute_toggle`, `open_app`, `navigate`, `search_web`,
  `media_play`, `media_pause`, `media_next`, `media_previous`, `home`, `back`, `recents`, `click_text`, `say`,
  or `broadcast` (arg is `action` or `action|package`).
- `arg`: the argument; `{name}` is replaced by what was captured. `volume_set` accepts digits or words ("fifty").
- `confirm` (optional): `true` asks for an on-screen OK before running.
- `back`, `recents` and `click_text` need the optional accessibility service.

Use **Diagnostics** to find the broadcast actions your unit's own apps listen for (for example for radio or mute),
then add a macro that sends them.
